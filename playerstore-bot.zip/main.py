import asyncio
import re
import base64
import binascii
import io
from datetime import datetime, timedelta

from log import log_info, log_erro

from telegram import (
    Update,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    CopyTextButton,
    InlineQueryResultArticle,
    InlineQueryResultPhoto,
    InlineQueryResultCachedPhoto,
    InputTextMessageContent,
    BotCommand,
)

from telegram.ext import (
    Application,
    CommandHandler,
    CallbackQueryHandler,
    ContextTypes,
    MessageHandler,
    InlineQueryHandler,
    filters,
)

from config import (
    BOT_TOKEN,
    verificar_configuracao,
    GRUPO_CLIENTES,
    ADMIN_ID,
)

from database import (
    criar_tabelas,
    criar_usuario,
    listar_pedidos_cliente,
    obter_detalhes_pedido,
    consultar_usuario,
    consultar_saldo,
    conectar,
    retirar_saldo,
    adicionar_saldo,
    criar_pagamento,
    contar_pagamentos_pendentes_usuario,
    consultar_pagamento,
    atualizar_status_pagamento,
    listar_pagamentos_pendentes,
    processar_pagamento_pago,
    retirar_login_disponivel,
    liberar_logins_pedido,
    listar_todos_produtos,
    consultar_estoque_logins,
    buscar_categoria,
    obter_configuracao,
    adicionar_item_carrinho,
    listar_itens_carrinho,
    remover_item_carrinho,
    limpar_carrinho,
    buscar_produtos_por_nome,
    obter_imagem_produto,
    contar_compras_usuario,
    salvar_topico_suporte,
    obter_topico_suporte,
    remover_topico_suporte,
    obter_usuario_por_topico,
    usuario_ja_recebeu_lembrete,
    marcar_lembrete_enviado,
    listar_grupos_obrigatorios,
    criar_encomenda,
    obter_encomenda,
    definir_valor_encomenda,
    marcar_encomenda_paga,
    marcar_encomenda_entregue,
    cancelar_encomenda,
    registrar_mensagem_grupo_anuncios,
    registrar_boas_vindas_pendente,
    listar_contas_usuario,
    consultar_login,
    produto_ja_alertou_estoque_baixo,
    marcar_alerta_estoque_enviado,
    resetar_alerta_estoque,
    registrar_aviso_reposicao,
    listar_interessados_reposicao,
    remover_avisos_reposicao,
)

from menu import menu_principal
from tarefas import (
    iniciar_verificador,
    parar_verificador,
    enviar_relatorio_vendas,
    INTERVALO_VERIFICACAO,
)
from catalogo import (
    menu_catalogo,
    menu_categorias,
    menu_produtos_categoria,
    texto_selecionar_categoria,
    buscar_produto,
    listar_produtos,
)
from pushinpay import criar_pix, consultar_pix
from restaurar import (
    comando_restaurar,
    cancelar_restauracao,
    receber_banco_restaurar,
)

from database import (
    cadastrar_produto as _cadastrar_produto_lote,
    buscar_categoria_por_nome as _buscar_categoria_lote,
    definir_categoria_produto as _definir_categoria_lote,
    listar_todos_produtos as _listar_produtos_lote,
)

from admin import (
    comando_admin,
    botoes_admin,
    processar_admin_texto,
    processar_admin_midia,
)


# =========================================================
# CONFIGURAÇÕES
# =========================================================

VALOR_MINIMO = 5.00
VALOR_MAXIMO = 499.00


# =========================================================
# MODO MANUTENÇÃO
# =========================================================

TEXTO_MANUTENCAO = (
    "🛠️ *BOT EM MANUTENÇÃO*\n\n"
    "Estamos atualizando nosso estoque/sistema "
    "no momento.\n\n"
    "Voltamos em breve! Tente novamente daqui "
    "a pouco. 🙏"
)


def modo_manutencao_ativo():
    return (
        obter_configuracao("modo_manutencao")
        == "1"
    )


def eh_admin_principal(user_id):
    try:
        return int(user_id) == int(ADMIN_ID)
    except (ValueError, TypeError):
        return False


# =========================================================
# GRUPO OBRIGATÓRIO (ENTRAR ANTES DE USAR O BOT)
# =========================================================

async def verificar_membro_grupo(
    bot,
    grupo_id,
    user_id,
):
    try:
        membro = await bot.get_chat_member(
            chat_id=int(grupo_id),
            user_id=user_id,
        )

        return membro.status in (
            "member",
            "administrator",
            "creator",
        )

    except Exception as erro:
        log_erro(
            "ERRO AO VERIFICAR MEMBRO DO GRUPO "
            "(permitindo acesso por segurança):",
            repr(erro),
        )
        # Falha ao verificar (ex: bot sem
        # permissão, grupo errado) — libera o
        # acesso pra não travar todo mundo por
        # causa de uma configuração ruim.
        return True


async def mostrar_tela_entrar_grupo(
    update_or_query,
    links,
    e_callback=False,
):

    if isinstance(links, str):
        links = [links]

    if len(links) == 1:
        texto = (
            "🔒 *ENTRE NO NOSSO GRUPO PRIMEIRO*\n\n"
            "Pra usar o bot, você precisa entrar "
            "no nosso grupo/canal oficial.\n\n"
            "1️⃣ Toque em \"Entrar no grupo\"\n"
            "2️⃣ Depois volte aqui e toque em "
            "\"✅ Já entrei\""
        )
    else:
        texto = (
            "🔒 *ENTRE NOS NOSSOS GRUPOS PRIMEIRO*\n\n"
            "Pra usar o bot, você precisa entrar "
            f"em todos os {len(links)} grupos/canais "
            "abaixo.\n\n"
            "1️⃣ Toque em cada botão abaixo\n"
            "2️⃣ Depois volte aqui e toque em "
            "\"✅ Já entrei\""
        )

    linhas_botoes = []

    for indice, link in enumerate(links, start=1):

        texto_botao = (
            "👥 Entrar no grupo"
            if len(links) == 1
            else f"👥 Entrar no grupo {indice}"
        )

        linhas_botoes.append(
            [
                InlineKeyboardButton(
                    texto_botao,
                    url=link,
                )
            ]
        )

    linhas_botoes.append(
        [
            InlineKeyboardButton(
                "✅ Já entrei",
                callback_data="checkjoin",
            )
        ]
    )

    botoes = InlineKeyboardMarkup(linhas_botoes)

    if e_callback:
        await update_or_query.answer()
        try:
            await update_or_query.edit_message_text(
                texto,
                reply_markup=botoes,
                parse_mode="Markdown",
            )
        except Exception:
            pass
    else:
        await update_or_query.message.reply_text(
            texto,
            reply_markup=botoes,
            parse_mode="Markdown",
        )


async def bloqueado_por_grupo_obrigatorio(
    bot,
    user_id,
):
    """
    Retorna a lista de links dos grupos/canais
    obrigatórios que o usuário ainda não entrou.
    Retorna lista vazia (falsy) se está liberado.
    """

    if eh_admin_principal(user_id):
        return []

    grupos = listar_grupos_obrigatorios()

    if not grupos:
        return []

    pendentes = []

    for _registro_id, grupo_id, link in grupos:

        membro = await verificar_membro_grupo(
            bot,
            grupo_id,
            user_id,
        )

        if not membro:
            pendentes.append(link)

    return pendentes


# =========================================================
# ESTOQUE BAIXO
# =========================================================

ESTOQUE_MINIMO_PADRAO = 3


async def verificar_estoque_baixo(
    bot,
    produto_id,
    nome_produto,
):

    try:

        limite = obter_configuracao(
            "estoque_minimo"
        )

        limite = (
            int(limite)
            if limite
            else ESTOQUE_MINIMO_PADRAO
        )

        estoque_atual = consultar_estoque_logins(
            produto_id
        )

        if estoque_atual > limite:
            resetar_alerta_estoque(
                produto_id
            )
            return

        if produto_ja_alertou_estoque_baixo(
            produto_id
        ):
            return

        marcar_alerta_estoque_enviado(
            produto_id
        )

        if estoque_atual <= 0:
            await anunciar_esgotado_grupo(
                bot,
                nome_produto,
            )
        else:
            await anunciar_estoque_baixo_grupo(
                bot,
                nome_produto,
                estoque_atual,
            )

        await bot.send_message(
            chat_id=ADMIN_ID,
            text=(
                "📉 *ESTOQUE BAIXO*\n\n"
                f"📦 *Produto:* {nome_produto}\n"
                f"🔐 *Restam:* {estoque_atual} "
                "conta(s)\n\n"
                "Considere repor o estoque em "
                "breve."
            ),
            parse_mode="Markdown",
        )

    except Exception as erro:
        log_erro(
            "ERRO NO ALERTA DE ESTOQUE BAIXO:",
            repr(erro),
        )


def mascarar_nome_cliente(nome, usuario_id):
    """Gera uma identificação parcial do cliente pra usar
    em anúncios públicos, tipo 'Ana…' ou 'Cliente #4521'
    quando não há nome disponível — nunca expõe o nome
    completo nem o @username.

    Usa reticências (…) em vez de asteriscos (*) de
    propósito: asteriscos são o símbolo de negrito no
    Markdown do Telegram, e três asteriscos soltos no meio
    do texto quebram a formatação da mensagem inteira,
    fazendo o Telegram recusar o envio."""

    nome = (nome or "").strip()

    # Remove caracteres que têm significado especial no
    # Markdown do Telegram (*, _, [, ]) do pedaço do nome
    # que será exibido, por segurança extra.
    nome_limpo = re.sub(r"[*_\[\]]", "", nome)

    if len(nome_limpo) >= 2:
        return f"{nome_limpo[:3]}…"

    return f"Cliente #{str(usuario_id)[-4:]}"


async def anunciar_venda_grupo(
    bot,
    nome_produto,
    preco,
    quantidade=1,
    nome_cliente=None,
    usuario_id=None,
):
    try:

        grupo_id = obter_configuracao(
            "grupo_anuncios_id"
        )

        if not grupo_id:
            log_info(
                "ℹ️ Anúncio de venda ignorado: "
                "nenhum grupo de anúncios "
                "configurado."
            )
            return

        try:
            grupo_id_int = int(grupo_id)
        except ValueError:
            log_erro(
                "ERRO AO ANUNCIAR VENDA:",
                f"grupo_anuncios_id inválido: "
                f"{grupo_id!r}",
            )
            return

        me = await bot.get_me()

        valor_total = float(preco) * int(quantidade)

        if quantidade > 1:
            linha_quantidade = (
                f"📦 Quantidade: {quantidade}\n"
            )
        else:
            linha_quantidade = ""

        identificacao = mascarar_nome_cliente(
            nome_cliente, usuario_id
        )

        mensagem_enviada = await bot.send_message(
            chat_id=grupo_id_int,
            text=(
                "🎉 *NOVA VENDA REALIZADA!*\n\n"
                f"👤 {identificacao} comprou: "
                f"{nome_produto}\n"
                f"{linha_quantidade}"
                f"💰 R$ {valor_total:.2f}\n"
                "⚡ Corra antes que acabe — "
                "boas compras! 🛒🔥"
            ),
            reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(
                            "🤖 Acessar o bot",
                            url=(
                                f"https://t.me/"
                                f"{me.username}"
                            ),
                        )
                    ]
                ]
            ),
            parse_mode="Markdown",
        )

        registrar_mensagem_grupo_anuncios(
            grupo_id_int,
            mensagem_enviada.message_id,
        )

        log_info(
            f"✅ Venda anunciada no grupo "
            f"{grupo_id_int}: {nome_produto}"
        )

    except Exception as erro:
        log_erro(
            "ERRO AO ANUNCIAR VENDA:",
            repr(erro),
        )


# =========================================================
# BOAS-VINDAS AUTOMÁTICAS EM GRUPO (COM AUTO-APAGAR)
# =========================================================
# Funciona em qualquer grupo em que o bot seja admin —
# não precisa configurar ID de grupo. Ao entrar um membro
# novo, manda uma mensagem de boas-vindas mencionando o
# nome dele. O horário de apagar é salvo no banco (não só
# na memória), então mesmo que o bot reinicie antes dos 30
# minutos passarem, a mensagem ainda é apagada corretamente
# assim que o bot voltar a rodar.

TEMPO_APAGAR_BOAS_VINDAS = 30 * 60  # 30 minutos
TEMPO_APAGAR_DESPEDIDA = 15 * 60  # 15 minutos


async def boas_vindas_novo_membro(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
):
    mensagem = update.message

    if not mensagem or not mensagem.new_chat_members:
        return

    log_info(
        "👋 Evento de novo(s) membro(s) recebido "
        f"no chat {mensagem.chat_id}: "
        f"{len(mensagem.new_chat_members)} "
        "pessoa(s)."
    )

    for novo_membro in mensagem.new_chat_members:

        # Ignora o próprio bot sendo adicionado ao grupo.
        if novo_membro.is_bot and (
            novo_membro.id == context.bot.id
        ):
            continue

        nome = (
            novo_membro.first_name
            or novo_membro.username
            or "novo membro"
        )

        try:
            me = await context.bot.get_me()

            mensagem_enviada = await context.bot.send_message(
                chat_id=mensagem.chat_id,
                text=(
                    f"🎉 *Seja bem-vindo(a), {nome}!*\n\n"
                    "Você acaba de entrar na "
                    "*PLAYERSTORE* — sua loja de telas, "
                    "contas e streaming premium com os "
                    "melhores preços! 🛒✨\n\n"
                    "👉 Fale com o bot pra ver o "
                    "catálogo completo e fazer seu "
                    "pedido em poucos cliques.\n"
                    "💬 Alguma dúvida? É só chamar o "
                    "suporte por lá.\n\n"
                    "🔥 Aproveite e boas compras!"
                ),
                reply_markup=InlineKeyboardMarkup(
                    [
                        [
                            InlineKeyboardButton(
                                "🛒 Acessar o bot",
                                url=(
                                    f"https://t.me/"
                                    f"{me.username}"
                                ),
                            )
                        ]
                    ]
                ),
                parse_mode="Markdown",
            )

            registrar_boas_vindas_pendente(
                mensagem.chat_id,
                mensagem_enviada.message_id,
                TEMPO_APAGAR_BOAS_VINDAS,
            )

            log_info(
                f"✅ Boas-vindas enviada pra {nome} "
                f"no chat {mensagem.chat_id}."
            )

        except Exception as erro:
            log_erro(
                "ERRO AO DAR BOAS-VINDAS:",
                repr(erro),
            )


async def despedida_membro(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
):
    mensagem = update.message

    if not mensagem or not mensagem.left_chat_member:
        return

    ex_membro = mensagem.left_chat_member

    log_info(
        "🚪 Evento de saída recebido no chat "
        f"{mensagem.chat_id}: {ex_membro.first_name}"
    )

    # Ignora o próprio bot sendo removido do grupo.
    if ex_membro.is_bot and (
        ex_membro.id == context.bot.id
    ):
        return

    nome = (
        ex_membro.first_name
        or ex_membro.username
        or "alguém"
    )

    try:
        total_membros = (
            await context.bot.get_chat_member_count(
                mensagem.chat_id
            )
        )

        mensagem_enviada = await context.bot.send_message(
            chat_id=mensagem.chat_id,
            text=(
                "🚨 *Atenção, comunicado oficial* 🚨\n\n"
                f"*{nome}* resolveu abandonar o "
                "prestigiado grupo da *PLAYERSTORE* "
                "⚡.\n"
                "Sim, é verdade… achou que o mundo lá "
                "fora ofereceria algo melhor.\n"
                "Boa sorte nessa missão impossível! "
                "🙃\n\n"
                "Enquanto isso, nós, os incríveis "
                f"{total_membros} que realmente "
                "importam, seguimos firmes por aqui! 🔥"
            ),
            parse_mode="Markdown",
        )

        registrar_boas_vindas_pendente(
            mensagem.chat_id,
            mensagem_enviada.message_id,
            TEMPO_APAGAR_DESPEDIDA,
        )

        log_info(
            f"✅ Despedida enviada pra {nome} "
            f"no chat {mensagem.chat_id}."
        )

    except Exception as erro:
        log_erro(
            "ERRO NA MENSAGEM DE SAÍDA:",
            repr(erro),
        )


async def anunciar_estoque_baixo_grupo(
    bot,
    nome_produto,
    estoque_atual,
):
    """Avisa publicamente no grupo que restam poucas
    unidades de um produto — gera urgência real, já que o
    número vem direto do estoque atual, sem inventar nada."""

    try:

        grupo_id = obter_configuracao(
            "grupo_anuncios_id"
        )

        if not grupo_id:
            return

        try:
            grupo_id_int = int(grupo_id)
        except ValueError:
            return

        me = await bot.get_me()

        mensagem_enviada = await bot.send_message(
            chat_id=grupo_id_int,
            text=(
                "⚠️ *ÚLTIMAS UNIDADES!*\n\n"
                f"🛒 {nome_produto}\n"
                f"📦 Restam apenas {estoque_atual} "
                "unidade(s)!\n\n"
                "🔥 Corra antes que acabe!"
            ),
            reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(
                            "🤖 Acessar o bot",
                            url=(
                                f"https://t.me/"
                                f"{me.username}"
                            ),
                        )
                    ]
                ]
            ),
            parse_mode="Markdown",
        )

        registrar_mensagem_grupo_anuncios(
            grupo_id_int,
            mensagem_enviada.message_id,
        )

    except Exception as erro:
        log_erro(
            "ERRO AO ANUNCIAR ESTOQUE BAIXO:",
            repr(erro),
        )


async def anunciar_esgotado_grupo(
    bot,
    nome_produto,
):
    try:

        grupo_id = obter_configuracao(
            "grupo_anuncios_id"
        )

        if not grupo_id:
            return

        try:
            grupo_id_int = int(grupo_id)
        except ValueError:
            return

        me = await bot.get_me()

        mensagem_enviada = await bot.send_message(
            chat_id=grupo_id_int,
            text=(
                "❌ *Estoque esgotado!* "
                f"{nome_produto}"
            ),
            reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(
                            "🤖 Acessar o bot",
                            url=(
                                f"https://t.me/"
                                f"{me.username}"
                            ),
                        )
                    ]
                ]
            ),
            parse_mode="Markdown",
        )

        registrar_mensagem_grupo_anuncios(
            grupo_id_int,
            mensagem_enviada.message_id,
        )

    except Exception as erro:
        log_erro(
            "ERRO AO ANUNCIAR ESGOTAMENTO:",
            repr(erro),
        )


# =========================================================
# ENVIAR MENU PRINCIPAL (COM BANNER, SE CADASTRADO)
# =========================================================

async def enviar_menu_principal(
    chat_id,
    context: ContextTypes.DEFAULT_TYPE,
    texto,
):

    imagem_id = obter_configuracao(
        "imagem_catalogo_id"
    )
    imagem_tipo = obter_configuracao(
        "imagem_catalogo_tipo"
    )

    if imagem_id:

        try:
            if imagem_tipo == "animation":
                await context.bot.send_animation(
                    chat_id=chat_id,
                    animation=imagem_id,
                    caption=texto,
                    reply_markup=menu_principal(),
                    parse_mode="Markdown",
                )
            else:
                await context.bot.send_photo(
                    chat_id=chat_id,
                    photo=imagem_id,
                    caption=texto,
                    reply_markup=menu_principal(),
                    parse_mode="Markdown",
                )
            return
        except Exception as erro:
            log_erro(
                "ERRO AO ENVIAR BANNER DO MENU:",
                repr(erro),
            )

    await context.bot.send_message(
        chat_id=chat_id,
        text=texto,
        reply_markup=menu_principal(),
        parse_mode="Markdown",
    )


# =========================================================
# LEMBRETE DE COMPRA (5 MINUTOS APÓS O /start)
# =========================================================

LEMBRETE_DELAY_SEGUNDOS = 5 * 60


def montar_mensagem_compra_realizada(
    itens,
    total,
    novo_saldo,
):
    """Monta a mensagem de entrega no MESMO formato fixo
    para qualquer compra (produto único ou carrinho com
    vários produtos), sempre começando com o agradecimento.

    `itens` é uma lista de dicts:
        {
            "nome": nome do produto,
            "quantidade": int,
            "preco_unitario": float,
            "contas": [dados1, dados2, ...],
        }
    """

    texto = (
        "🙏 *Obrigado pela sua compra!*\n\n"
        "✅ *COMPRA REALIZADA COM SUCESSO*\n"
        "━━━━━━━━━━━━━━━━━━\n"
    )

    for item in itens:

        subtotal = (
            item["preco_unitario"]
            * item["quantidade"]
        )

        texto += (
            f"🛒 *Produto:* {item['nome']}\n"
            f"📦 *Quantidade:* "
            f"{item['quantidade']}\n"
            f"💰 *Preço unitário:* R$ "
            f"{item['preco_unitario']:.2f}\n"
            f"💵 *Subtotal:* R$ {subtotal:.2f}\n\n"
        )

        texto += "🎁 *SEUS DADOS DE ACESSO*\n"

        for indice, dados in enumerate(
            item["contas"], start=1
        ):
            texto += (
                f"🔐 *Conta {indice}*\n"
                f"```\n{dados}\n```\n"
            )

        texto += "\n"

    texto += (
        "━━━━━━━━━━━━━━━━━━\n\n"
        f"💵 *Total pago:* R$ {total:.2f}\n"
        f"💳 *Saldo restante:* R$ {novo_saldo:.2f}\n\n"
        "⚡ Entrega realizada automaticamente.\n"
        "💬 Qualquer dúvida, é só chamar o suporte!"
    )

    return texto


async def enviar_lembrete_compra(
    bot,
    usuario_id,
):

    await asyncio.sleep(
        LEMBRETE_DELAY_SEGUNDOS
    )

    try:

        if usuario_ja_recebeu_lembrete(
            usuario_id
        ):
            return

        if contar_compras_usuario(
            usuario_id
        ) > 0:
            return

        if modo_manutencao_ativo():
            return

        marcar_lembrete_enviado(
            usuario_id
        )

        await bot.send_message(
            chat_id=usuario_id,
            text=(
                "👋 Olá! Vi que você ainda não "
                "realizou nenhuma compra.\n\n"
                "Posso te ajudar? Escolha uma "
                "das opções abaixo 👇"
            ),
            reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(
                            "🆘 Suporte",
                            callback_data="suporte",
                        ),
                        InlineKeyboardButton(
                            "🛍️ Comprar Agora",
                            callback_data="catalogo",
                        ),
                    ],
                    [
                        InlineKeyboardButton(
                            "🛒 Carrinho",
                            callback_data="carrinho",
                        ),
                        InlineKeyboardButton(
                            "👀 Termos",
                            callback_data="termos",
                        ),
                    ],
                ]
            ),
        )

    except Exception as erro:
        log_erro(
            "ERRO NO LEMBRETE DE COMPRA:",
            repr(erro),
        )


# =========================================================
# START
# =========================================================

async def start(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
):
    usuario = update.effective_user

    if not usuario:
        return

    if modo_manutencao_ativo() and not eh_admin_principal(
        usuario.id
    ):
        if update.message:
            await update.message.reply_text(
                TEXTO_MANUTENCAO,
                parse_mode="Markdown",
            )
        return

    link_pendente = await bloqueado_por_grupo_obrigatorio(
        context.bot,
        usuario.id,
    )

    if link_pendente:
        await mostrar_tela_entrar_grupo(
            update,
            link_pendente,
            e_callback=False,
        )
        return

    criar_usuario(
        usuario.id,
        usuario.first_name or "",
        usuario.username or "",
    )

    context.user_data.clear()

    saldo = float(
        consultar_saldo(usuario.id) or 0
    )

    total_compras = contar_compras_usuario(
        usuario.id
    )

    username_texto = (
        f"`@{usuario.username}`"
        if usuario.username
        else "Não informado"
    )

    texto = (
        "✨ *BEM-VINDO À PLAYER STORE!* ✨\n\n"
        "🎬 O bot mais completo de contas premium "
        "e telas exclusivas!\n\n"
        "━━━━━━━━━━━━━━━━━━\n"
        "👤 *SUAS INFORMAÇÕES*\n"
        "━━━━━━━━━━━━━━━━━━\n\n"
        f"👤 Nome: {usuario.first_name or 'cliente'}\n"
        f"✏️ Username: {username_texto}\n"
        f"🆔 ID: `{usuario.id}`\n"
        f"💲 Saldo: R$ {saldo:.2f}\n"
        f"🛍️ Compras: {total_compras}\n\n"
        "━━━━━━━━━━━━━━━━━━\n\n"
        "🚀 Aproveite as melhores ofertas!"
    )

    if update.message:
        await enviar_menu_principal(
            update.message.chat_id,
            context,
            texto,
        )

    if not eh_admin_principal(usuario.id):
        asyncio.create_task(
            enviar_lembrete_compra(
                context.bot,
                usuario.id,
            )
        )


# =========================================================
# COMPRAR PRODUTO
# =========================================================

async def comprar_produto(
    query,
    context,
    produto_id,
    usuario_id,
    quantidade=1,
):
    produto = buscar_produto(produto_id)

    if not produto:
        await query.answer(
            "❌ Produto não encontrado.",
            show_alert=True,
        )
        return

    _, nome, descricao, preco, estoque = produto

    preco = float(preco)
    estoque = int(estoque)
    quantidade = int(quantidade)

    if quantidade <= 0:
        await query.answer(
            "❌ Quantidade inválida.",
            show_alert=True,
        )
        return

    # O estoque real de contas é a tabela logins.
    conn = conectar()
    cursor = conn.cursor()

    try:
        cursor.execute(
            """
            SELECT COUNT(*)
            FROM logins
            WHERE produto_id = ?
              AND status = 'disponivel'
            """,
            (produto_id,),
        )
        estoque_logins = int(cursor.fetchone()[0])
    except Exception as erro:
        conn.close()
        log_erro("ERRO AO CONSULTAR ESTOQUE DE LOGINS:", repr(erro))
        await query.answer(
            "❌ Não foi possível consultar o estoque.",
            show_alert=True,
        )
        return
    finally:
        try:
            conn.close()
        except Exception:
            pass

    if estoque_logins < quantidade:
        await query.answer(
            f"❌ Estoque insuficiente.\n\n"
            f"📦 Disponível: {estoque_logins}\n"
            f"🛒 Solicitado: {quantidade}",
            show_alert=True,
        )
        return

    valor_total = preco * quantidade

    saldo = float(consultar_saldo(usuario_id) or 0)

    if saldo < valor_total:
        await editar_ou_substituir(
            query,
            context,
            "❌ *SALDO INSUFICIENTE*\n\n"
            "━━━━━━━━━━━━━━━━━━\n"
            f"🛒 *Produto:* {nome}\n"
            f"💰 *Total:* R$ {valor_total:.2f}\n"
            f"💳 *Seu saldo:* R$ {saldo:.2f}\n"
            f"💵 *Faltam:* R$ {valor_total - saldo:.2f}\n"
            "━━━━━━━━━━━━━━━━━━\n\n"
            "Adicione saldo para concluir a compra.",
            reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(
                            "💵 ADICIONAR SALDO",
                            callback_data="adicionar_saldo",
                        )
                    ],
                    [
                        InlineKeyboardButton(
                            "⬅️ Voltar ao produto",
                            callback_data=f"produto_{produto_id}",
                        )
                    ],
                ]
            ),
            parse_mode="Markdown",
        )
        return

    # Retira o saldo antes da criação do pedido.
    sucesso = retirar_saldo(usuario_id, valor_total)

    if not sucesso:
        await query.answer(
            "❌ Não foi possível realizar a compra.",
            show_alert=True,
        )
        return

    pedido_id = None

    try:
        conn = conectar()
        cursor = conn.cursor()

        # Confere novamente o estoque imediatamente antes do pedido.
        cursor.execute(
            """
            SELECT COUNT(*)
            FROM logins
            WHERE produto_id = ?
              AND status = 'disponivel'
            """,
            (produto_id,),
        )
        estoque_atual = int(cursor.fetchone()[0])

        if estoque_atual < quantidade:
            conn.close()
            adicionar_saldo(usuario_id, valor_total)

            await query.answer(
                "❌ O estoque mudou. Tente novamente.",
                show_alert=True,
            )
            return

        cursor.execute(
            """
            INSERT INTO pedidos
            (
                usuario_id,
                produto_id,
                quantidade,
                valor,
                status
            )
            VALUES (?, ?, ?, ?, 'pago')
            """,
            (
                usuario_id,
                produto_id,
                quantidade,
                valor_total,
            ),
        )

        pedido_id = cursor.lastrowid
        conn.commit()
        conn.close()

    except Exception as erro:
        try:
            conn.rollback()
            conn.close()
        except Exception:
            pass

        adicionar_saldo(usuario_id, valor_total)

        log_erro("ERRO AO REGISTRAR COMPRA:", repr(erro))

        await query.answer(
            "❌ Erro ao finalizar a compra.",
            show_alert=True,
        )
        return

    # Entrega das contas.
    contas_entregues = []

    try:
        for _ in range(quantidade):
            login = retirar_login_disponivel(
                produto_id,
                usuario_id,
                pedido_id,
            )

            if not login:
                raise RuntimeError(
                    "Não existe login disponível para entrega."
                )

            contas_entregues.append(login["dados"])

    except Exception as erro:
        log_erro("ERRO NA ENTREGA:", repr(erro))

        try:
            conn = conectar()
            cursor = conn.cursor()
            cursor.execute(
                """
                UPDATE pedidos
                SET status = 'cancelado'
                WHERE id = ?
                """,
                (pedido_id,),
            )
            conn.commit()
            conn.close()
        except Exception as erro_db:
            log_erro("ERRO AO CANCELAR PEDIDO:", repr(erro_db))

        try:
            liberar_logins_pedido(pedido_id)
        except Exception as erro_liberar:
            log_erro(
                "ERRO AO LIBERAR LOGINS DO PEDIDO:",
                repr(erro_liberar),
            )

        adicionar_saldo(usuario_id, valor_total)

        await editar_ou_substituir(
            query,
            context,
            "❌ *COMPRA NÃO CONCLUÍDA*\n\n"
            "O estoque de contas acabou antes da entrega.\n\n"
            "💰 O valor foi devolvido ao seu saldo.",
            reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(
                            "🛒 Ver catálogo",
                            callback_data="catalogo",
                        )
                    ],
                    [
                        InlineKeyboardButton(
                            "↩️ Voltar ao menu",
                            callback_data="voltar_menu",
                        )
                    ],
                ]
            ),
            parse_mode="Markdown",
        )
        return

    novo_saldo = float(consultar_saldo(usuario_id) or 0)

    await verificar_estoque_baixo(
        context.bot,
        produto_id,
        nome,
    )

    await anunciar_venda_grupo(
        context.bot,
        nome,
        preco,
        quantidade,
        nome_cliente=query.from_user.first_name,
        usuario_id=usuario_id,
    )

    texto = montar_mensagem_compra_realizada(
        itens=[
            {
                "nome": nome,
                "quantidade": quantidade,
                "preco_unitario": preco,
                "contas": contas_entregues,
            }
        ],
        total=valor_total,
        novo_saldo=novo_saldo,
    )

    botoes = InlineKeyboardMarkup(
        [
            [
                InlineKeyboardButton(
                    "🛒 Comprar novamente",
                    callback_data=f"produto_{produto_id}",
                )
            ],
            [
                InlineKeyboardButton(
                    "🛒 Ver catálogo",
                    callback_data="catalogo",
                )
            ],
            [
                InlineKeyboardButton(
                    "↩️ Voltar ao menu",
                    callback_data="voltar_menu",
                )
            ],
        ]
    )

    await editar_ou_substituir(
        query,
        context,
        texto,
        reply_markup=botoes,
        parse_mode="Markdown",
    )


# =========================================================
# PEDIR QUANTIDADE
# =========================================================

async def pedir_quantidade_produto(
    query,
    context,
    produto_id,
):
    produto = buscar_produto(produto_id)

    if not produto:
        await query.answer(
            "❌ Produto não encontrado.",
            show_alert=True,
        )
        return

    _, nome, descricao, preco, estoque = produto

    preco = float(preco)
    estoque = int(estoque)

    # Estoque real.
    conn = conectar()
    cursor = conn.cursor()

    try:
        cursor.execute(
            """
            SELECT COUNT(*)
            FROM logins
            WHERE produto_id = ?
              AND status = 'disponivel'
            """,
            (produto_id,),
        )
        estoque_real = int(cursor.fetchone()[0])
    except Exception as erro:
        log_erro("ERRO AO CONSULTAR ESTOQUE:", repr(erro))
        estoque_real = estoque
    finally:
        conn.close()

    if estoque_real <= 0:
        await query.answer(
            "📦 Produto sem estoque.",
            show_alert=True,
        )
        return

    context.user_data["aguardando_quantidade"] = True
    context.user_data["produto_quantidade_id"] = produto_id
    context.user_data["aguardando_valor"] = False

    await editar_ou_substituir(
        query,
        context,
        "🛍️ *COMPRAR EM QUANTIDADE*\n\n"
        f"🛒 *Produto:* {nome}\n"
        f"💰 *Preço unitário:* R$ {preco:.2f}\n"
        f"📦 *Disponível:* {estoque_real}\n\n"
        "Digite a quantidade que deseja comprar.\n\n"
        "Exemplo:\n"
        "`1`\n"
        "`2`\n"
        "`5`",
        reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(
                        "⬅️ Voltar",
                        callback_data=f"produto_{produto_id}",
                    )
                ],
                [
                    InlineKeyboardButton(
                        "↩️ Voltar ao menu",
                        callback_data="voltar_menu",
                    )
                ],
            ]
        ),
        parse_mode="Markdown",
    )


# =========================================================
# PROCESSAR QUANTIDADE
# =========================================================

async def processar_quantidade_produto(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
):
    if not context.user_data.get("aguardando_quantidade"):
        return False

    if not update.message:
        return True

    produto_id = context.user_data.get("produto_quantidade_id")

    if not produto_id:
        context.user_data["aguardando_quantidade"] = False
        return True

    texto = (update.message.text or "").strip()

    try:
        quantidade = int(texto)
    except ValueError:
        await update.message.reply_text(
            "❌ Digite somente um número inteiro.\n\n"
            "Exemplo: `2`",
            parse_mode="Markdown",
        )
        return True

    if quantidade <= 0:
        await update.message.reply_text(
            "❌ A quantidade deve ser maior que zero."
        )
        return True

    produto = buscar_produto(produto_id)

    if not produto:
        context.user_data["aguardando_quantidade"] = False
        await update.message.reply_text(
            "❌ Produto não encontrado."
        )
        return True

    _, nome, descricao, preco, estoque = produto

    preco = float(preco)

    conn = conectar()
    cursor = conn.cursor()

    try:
        cursor.execute(
            """
            SELECT COUNT(*)
            FROM logins
            WHERE produto_id = ?
              AND status = 'disponivel'
            """,
            (produto_id,),
        )
        estoque_logins = int(cursor.fetchone()[0])
    except Exception as erro:
        log_erro("ERRO AO CONSULTAR ESTOQUE:", repr(erro))
        estoque_logins = 0
    finally:
        conn.close()

    if quantidade > estoque_logins:
        await update.message.reply_text(
            f"❌ Quantidade indisponível.\n\n"
            f"📦 Contas disponíveis: {estoque_logins}\n"
            f"🛒 Você pediu: {quantidade}"
        )
        return True

    valor_total = preco * quantidade
    saldo = float(
        consultar_saldo(update.effective_user.id) or 0
    )

    if saldo < valor_total:
        await update.message.reply_text(
            f"❌ Saldo insuficiente.\n\n"
            f"💳 Seu saldo: R$ {saldo:.2f}\n"
            f"💰 Total: R$ {valor_total:.2f}\n\n"
            f"💵 Faltam: R$ {valor_total - saldo:.2f}"
        )
        return True

    context.user_data["aguardando_quantidade"] = False
    context.user_data["quantidade_produto"] = quantidade

    texto = (
        "🛒 *CONFIRMAR COMPRA*\n\n"
        "━━━━━━━━━━━━━━━━━━\n"
        f"🛍️ *Produto:* {nome}\n"
        f"📦 *Quantidade:* {quantidade}\n"
        f"💰 *Preço unitário:* R$ {preco:.2f}\n"
        f"💵 *Total:* R$ {valor_total:.2f}\n"
        "━━━━━━━━━━━━━━━━━━\n\n"
        f"💳 *Seu saldo:* R$ {saldo:.2f}\n"
        f"💳 *Saldo após compra:* R$ {saldo - valor_total:.2f}\n\n"
        "⚡ *Entrega imediata*\n"
        "❌ Sem reembolso em Pix\n"
        "👩🏻‍💻 Suporte completo"
    )

    botoes = InlineKeyboardMarkup(
        [
            [
                InlineKeyboardButton(
                    "✅ CONFIRMAR COMPRA",
                    callback_data=(
                        f"confirmar_compra_{produto_id}_{quantidade}"
                    ),
                )
            ],
            [
                InlineKeyboardButton(
                    "⬅️ Voltar ao produto",
                    callback_data=f"produto_{produto_id}",
                )
            ],
            [
                InlineKeyboardButton(
                    "↩️ Voltar ao menu",
                    callback_data="voltar_menu",
                )
            ],
        ]
    )

    await update.message.reply_text(
        texto,
        reply_markup=botoes,
        parse_mode="Markdown",
    )

    return True


# =========================================================
# PEDIR VALOR
# =========================================================

async def pedir_valor_saldo(
    query,
    context,
):
    context.user_data["aguardando_valor"] = True
    context.user_data["valor_saldo"] = None
    context.user_data["aguardando_quantidade"] = False
    context.user_data["produto_quantidade_id"] = None

    await editar_ou_substituir(
        query,
        context,
        "💵 *ADICIONAR SALDO*\n\n"
        "💠 PIX AUTOMÁTICO\n\n"
        "Digite o valor que deseja adicionar.\n\n"
        f"▫️ Mínimo: R$ {VALOR_MINIMO:.2f}\n"
        f"▫️ Máximo: R$ {VALOR_MAXIMO:.2f}\n\n"
        "Exemplo:\n"
        "`10`\n"
        "`25,50`\n"
        "`100`",
        reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(
                        "⬅️ Voltar",
                        callback_data="voltar_menu",
                    )
                ]
            ]
        ),
        parse_mode="Markdown",
    )


# =========================================================
# ENCOMENDA (PRÉ-VENDA)
# =========================================================
# Fluxo: cliente descreve o que procura -> admin avalia e
# define o valor -> cliente paga com o saldo -> admin entrega
# manualmente e marca como concluída.

async def iniciar_encomenda(
    query,
    context,
):

    context.user_data.clear()
    context.user_data[
        "aguardando_encomenda_descricao"
    ] = True

    await editar_ou_substituir(
        query,
        context,
        "📝 *FAZER ENCOMENDA*\n\n"
        "Não achou o que procurava no catálogo? "
        "Descreva exatamente o que você quer "
        "(serviço, app, plataforma, duração "
        "etc).\n\n"
        "Vamos avaliar e te avisamos o valor "
        "por aqui mesmo.",
        reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(
                        "⬅️ Voltar",
                        callback_data="voltar_menu",
                    )
                ]
            ]
        ),
        parse_mode="Markdown",
    )


async def processar_descricao_encomenda(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
):

    if not context.user_data.get(
        "aguardando_encomenda_descricao"
    ):
        return

    if not update.message:
        return

    texto = (update.message.text or "").strip()

    if len(texto) < 5:
        await update.message.reply_text(
            "❌ Descreva com um pouco mais de "
            "detalhe o que você procura."
        )
        return

    context.user_data[
        "aguardando_encomenda_descricao"
    ] = False

    usuario = update.effective_user

    encomenda_id = criar_encomenda(
        usuario.id,
        texto,
    )

    await update.message.reply_text(
        "✅ *Encomenda recebida!*\n\n"
        "Vamos avaliar seu pedido e te "
        "avisamos o valor por aqui em breve.",
        parse_mode="Markdown",
    )

    username_texto = (
        f"@{usuario.username}"
        if usuario.username
        else "Não informado"
    )

    try:
        await context.bot.send_message(
            chat_id=ADMIN_ID,
            text=(
                "📝 *NOVA ENCOMENDA*\n\n"
                "━━━━━━━━━━━━━━━━━━\n"
                f"🆔 *Encomenda:* `#{encomenda_id}`\n"
                f"👤 *Cliente:* "
                f"{usuario.first_name or ''}\n"
                f"🔗 *Username:* {username_texto}\n"
                f"🆔 *ID do cliente:* `{usuario.id}`\n"
                "━━━━━━━━━━━━━━━━━━\n\n"
                f"📋 *Pedido:*\n{texto}"
            ),
            reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(
                            "💰 Definir valor",
                            callback_data=(
                                "encomenda_valor_"
                                f"{encomenda_id}"
                            ),
                        )
                    ],
                    [
                        InlineKeyboardButton(
                            "❌ Recusar",
                            callback_data=(
                                "encomenda_recusar_"
                                f"{encomenda_id}"
                            ),
                        )
                    ],
                ]
            ),
            parse_mode="Markdown",
        )
    except Exception as erro:
        log_erro(
            "ERRO AO AVISAR ADMIN (ENCOMENDA):",
            repr(erro),
        )


# =========================================================
# QR CODE BASE64
# =========================================================

def converter_qr_code_base64(qr_code_base64):
    if not qr_code_base64:
        return None

    try:
        valor = str(qr_code_base64).strip()

        if "," in valor:
            valor = valor.split(",", 1)[1]

        dados = base64.b64decode(
            valor,
            validate=False,
        )

        if not dados:
            return None

        arquivo = io.BytesIO(dados)
        arquivo.seek(0)
        return arquivo

    except (
        ValueError,
        TypeError,
        binascii.Error,
    ):
        log_info("QR Code Base64 inválido.")
        return None


# =========================================================
# PROCESSAR VALOR
# =========================================================

async def processar_valor_saldo(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
):
    if not context.user_data.get("aguardando_valor"):
        return

    if not update.message:
        return

    texto = (update.message.text or "").strip()

    try:
        valor = float(
            texto.replace(",", ".")
        )
    except ValueError:
        await update.message.reply_text(
            "❌ Digite apenas um valor válido.\n\n"
            "Exemplo:\n"
            "`10`\n"
            "`25,50`\n"
            "`100`",
            parse_mode="Markdown",
        )
        return

    if valor < VALOR_MINIMO:
        await update.message.reply_text(
            f"❌ O valor mínimo é R$ {VALOR_MINIMO:.2f}."
        )
        return

    if valor > VALOR_MAXIMO:
        await update.message.reply_text(
            f"❌ O valor máximo é R$ {VALOR_MAXIMO:.2f}."
        )
        return

    valor = round(valor, 2)

    usuario = update.effective_user

    LIMITE_PIX_PENDENTES = 3

    pendentes = contar_pagamentos_pendentes_usuario(
        usuario.id
    )

    if pendentes >= LIMITE_PIX_PENDENTES:
        await update.message.reply_text(
            "❌ Você já tem PIX pendentes demais.\n\n"
            "Pague ou aguarde a expiração dos PIX "
            "gerados antes de criar um novo."
        )
        return

    context.user_data["valor_saldo"] = valor
    context.user_data["aguardando_valor"] = False

    mensagem = await update.message.reply_text(
        "⏳ *Gerando seu PIX...*",
        parse_mode="Markdown",
    )

    try:
        pix = await asyncio.to_thread(
            criar_pix,
            valor,
        )

        if not isinstance(pix, dict):
            raise RuntimeError(
                "Resposta inválida da PushinPay."
            )

        transacao_id = pix.get("id")
        qr_code = pix.get("qr_code")
        qr_code_base64 = pix.get("qr_code_base64")

        if not transacao_id:
            raise RuntimeError(
                "PushinPay não retornou o ID da transação."
            )

        if not qr_code:
            raise RuntimeError(
                "PushinPay não retornou o código PIX."
            )

        criar_pagamento(
            usuario.id,
            valor,
            transacao_id,
        )

        texto_pix = (
            "💎 *PIX AUTOMÁTICO*\n\n"
            "━━━━━━━━━━━━━━━━━━\n"
            f"💰 *Valor:* R$ {valor:.2f}\n"
            f"🆔 *ID da compra:* `{transacao_id}`\n"
            "⏳ *Status:* Aguardando pagamento\n"
            "━━━━━━━━━━━━━━━━━━\n\n"
            "📋 *PIX COPIA E COLA*\n\n"
            f"`{qr_code}`\n\n"
            "⚡ Após o pagamento, a confirmação será feita "
            "automaticamente.\n\n"
            "💰 O saldo será liberado assim que o pagamento "
            "for confirmado."
        )

        botoes = [
            [
                InlineKeyboardButton(
                    "📋 COPIAR CÓDIGO",
                    copy_text=CopyTextButton(
                        text=str(qr_code)
                    ),
                )
            ],
            [
                InlineKeyboardButton(
                    "⏰ AGUARDANDO PAGAMENTO",
                    callback_data=f"status_pagamento_{transacao_id}",
                )
            ],
            [
                InlineKeyboardButton(
                    "⬅️ Voltar ao menu",
                    callback_data="voltar_menu",
                )
            ],
        ]

        markup = InlineKeyboardMarkup(botoes)

        imagem_qr = converter_qr_code_base64(
            qr_code_base64
        )

        if imagem_qr:
            await mensagem.delete()

            await update.message.reply_photo(
                photo=imagem_qr,
                caption=texto_pix,
                reply_markup=markup,
                parse_mode="Markdown",
            )
        else:
            await mensagem.edit_text(
                texto_pix,
                reply_markup=markup,
                parse_mode="Markdown",
            )

    except Exception as erro:
        log_erro("ERRO AO GERAR PIX:", repr(erro))

        try:
            await mensagem.edit_text(
                "❌ *Não foi possível gerar o PIX.*\n\n"
                "Ocorreu um erro ao comunicar com a PushinPay.\n\n"
                "Tente novamente em alguns instantes.",
                parse_mode="Markdown",
            )
        except Exception:
            pass


# =========================================================
# PROCESSAR MÍDIA (FOTOS / GIFS)
# =========================================================

async def processar_midia_generico(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
):
    usuario = update.effective_user

    if (
        usuario
        and modo_manutencao_ativo()
        and not eh_admin_principal(usuario.id)
    ):
        if update.message:
            await update.message.reply_text(
                TEXTO_MANUTENCAO,
                parse_mode="Markdown",
            )
        return

    try:
        tratado_admin = await processar_admin_midia(
            update,
            context,
        )
        if tratado_admin:
            return
    except Exception as erro:
        log_erro(
            "ERRO NO PROCESSAMENTO DE MÍDIA ADMIN:",
            repr(erro),
        )

    if context.user_data.get("aguardando_suporte"):
        await processar_suporte(
            update,
            context,
        )
        return


# =========================================================
# PROCESSAR TEXTO
# =========================================================

async def processar_mensagem_texto(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
):
    usuario = update.effective_user

    if (
        usuario
        and modo_manutencao_ativo()
        and not eh_admin_principal(usuario.id)
    ):
        if update.message:
            await update.message.reply_text(
                TEXTO_MANUTENCAO,
                parse_mode="Markdown",
            )
        return

    try:
        if await processar_admin_texto(
            update,
            context,
        ):
            return
    except Exception as erro:
        log_erro("ERRO NO PROCESSAMENTO ADMIN:", repr(erro))

    if context.user_data.get("aguardando_quantidade"):
        await processar_quantidade_produto(
            update,
            context,
        )
        return

    if context.user_data.get("aguardando_valor"):
        await processar_valor_saldo(
            update,
            context,
        )
        return

    if context.user_data.get(
        "aguardando_encomenda_descricao"
    ):
        await processar_descricao_encomenda(
            update,
            context,
        )
        return

    if context.user_data.get("aguardando_pesquisa"):
        await processar_pesquisa_servico(
            update,
            context,
        )
        return

    if context.user_data.get("aguardando_suporte"):
        await processar_suporte(
            update,
            context,
        )
        return


# =========================================================
# VERIFICAR PAGAMENTO MANUAL
# =========================================================

async def verificar_pagamento(
    query,
    context,
    transacao_id,
):
    try:
        pagamento = consultar_pagamento(transacao_id)

        if not pagamento:
            await query.answer(
                "❌ Pagamento não encontrado.",
                show_alert=True,
            )
            return

        usuario_id = pagamento[1]
        valor = float(pagamento[2])
        status_banco = pagamento[4]

        if status_banco == "pago":
            saldo = consultar_saldo(usuario_id)

            await query.answer(
                f"✅ Pagamento já confirmado.\n"
                f"Saldo: R$ {float(saldo):.2f}",
                show_alert=True,
            )
            return

        transacao = await asyncio.to_thread(
            consultar_pix,
            transacao_id,
        )

        status = str(
            transacao.get("status", "")
        ).lower()

        log_info(
            f"Pagamento {transacao_id}: {status}"
        )

        if status == "paid":
            resultado = processar_pagamento_pago(
                transacao_id
            )

            if resultado:
                saldo = consultar_saldo(usuario_id)

                await editar_ou_substituir(
                    query,
                    context,
                    "✅ *PAGAMENTO CONFIRMADO!*\n\n"
                    f"💰 Valor recebido: R$ {valor:.2f}\n\n"
                    f"💳 Novo saldo: R$ {float(saldo):.2f}\n\n"
                    "🎉 Seu saldo foi adicionado com sucesso!",
                    reply_markup=menu_principal(),
                    parse_mode="Markdown",
                )
            else:
                await query.answer(
                    "✅ Pagamento já processado.",
                    show_alert=True,
                )

            return

        if status in ("created", "pending"):
            await query.answer(
                "⏳ O pagamento ainda está pendente.",
                show_alert=True,
            )
            return

        if status in (
            "canceled",
            "cancelled",
            "expired",
        ):
            atualizar_status_pagamento(
                transacao_id,
                "cancelado",
            )

            await editar_ou_substituir(
                query,
                context,
                "❌ *PAGAMENTO ENCERRADO*\n\n"
                "A cobrança não foi aprovada.\n\n"
                "💰 Nenhum saldo foi adicionado.",
                reply_markup=menu_principal(),
                parse_mode="Markdown",
            )
            return

        await query.answer(
            f"Status atual: {status or 'desconhecido'}",
            show_alert=True,
        )

    except Exception as erro:
        log_erro(
            "ERRO AO CONSULTAR PAGAMENTO:",
            repr(erro),
        )

        await query.answer(
            "❌ Erro ao consultar o pagamento.",
            show_alert=True,
        )



# =========================================================
# ESTOQUE PÚBLICO DE LOGINS
# =========================================================

async def mostrar_estoque_logins(
    query,
    context,
):
    produtos = listar_todos_produtos()

    if not produtos:
        texto = (
            "📦 *ESTOQUE DE LOGINS*\n\n"
            "❌ Nenhum produto cadastrado no momento."
        )

    else:
        texto = (
            "📦 *ESTOQUE DE LOGINS*\n\n"
            "Quantidade de contas disponíveis "
            "por produto:\n\n"
        )

        for produto in produtos:

            produto_id = produto[0]
            nome = produto[1]

            quantidade = consultar_estoque_logins(
                produto_id
            )

            if quantidade > 0:
                status_emoji = "✅"
            else:
                status_emoji = "❌"

            texto += (
                f"{status_emoji} *{nome}*\n"
                f"📊 Disponível: {quantidade}\n\n"
            )

    await editar_ou_substituir(
        query,
        context,
        texto,
        reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(
                        "🔄 ATUALIZAR",
                        callback_data="estoque_logins",
                    )
                ],
                [
                    InlineKeyboardButton(
                        "🛒 VER CATÁLOGO",
                        callback_data="catalogo",
                    )
                ],
                [
                    InlineKeyboardButton(
                        "↩️ VOLTAR AO MENU",
                        callback_data="voltar_menu",
                    )
                ],
            ]
        ),
        parse_mode="Markdown",
    )


# =========================================================
# STATUS DO PAGAMENTO
# =========================================================

async def mostrar_status_pagamento(
    query,
    transacao_id,
):
    pagamento = consultar_pagamento(
        transacao_id
    )

    if not pagamento:
        await query.answer(
            "❌ Pagamento não encontrado.",
            show_alert=True,
        )
        return

    status = pagamento[4]

    if status == "pago":
        saldo = consultar_saldo(
            pagamento[1]
        )

        await query.answer(
            f"✅ Pago!\nSaldo: R$ {float(saldo):.2f}",
            show_alert=True,
        )
        return

    if status == "cancelado":
        await query.answer(
            "❌ Esta cobrança foi encerrada.",
            show_alert=True,
        )
        return

    await query.answer(
        "⏰ Ainda aguardando o pagamento.\n\n"
        "O bot verifica automaticamente.",
        show_alert=True,
    )


# =========================================================
# BUSCA INLINE (@seubot termo, em qualquer chat)
# =========================================================

async def pesquisa_inline(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
):

    inline_query = update.inline_query

    if not inline_query:
        return

    if modo_manutencao_ativo() and not eh_admin_principal(
        inline_query.from_user.id
    ):
        try:
            await inline_query.answer(
                [
                    InlineQueryResultArticle(
                        id="manutencao",
                        title="🛠️ Bot em manutenção",
                        description=(
                            "Tente novamente em breve."
                        ),
                        input_message_content=(
                            InputTextMessageContent(
                                TEXTO_MANUTENCAO,
                                parse_mode="Markdown",
                            )
                        ),
                    )
                ],
                cache_time=1,
                is_personal=True,
            )
        except Exception:
            pass
        return

    termo = (inline_query.query or "").strip()

    if termo.lower().startswith("buscar_loguin"):
        termo = termo[len("buscar_loguin"):].strip()

    if termo:
        produtos = buscar_produtos_por_nome(
            termo
        )
    else:
        produtos = listar_produtos()

    resultados = []

    for produto in produtos[:50]:

        produto_id = produto[0]
        nome = produto[1]
        preco = float(produto[3])
        estoque = int(produto[4])

        imagem_url = obter_imagem_produto(
            produto_id
        )

        botao = InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(
                        "🛒 Ver produto",
                        callback_data=(
                            f"produto_{produto_id}"
                        ),
                    )
                ]
            ]
        )

        legenda = (
            f"🛍️ *{nome}*\n\n"
            f"💰 *Valor:* R$ {preco:.2f}\n"
            f"📦 *Estoque:* {estoque}"
        )

        if imagem_url and imagem_url.startswith(
            ("http://", "https://")
        ):
            # Imagem configurada por link direto.
            resultados.append(
                InlineQueryResultPhoto(
                    id=str(produto_id),
                    photo_url=imagem_url,
                    thumbnail_url=imagem_url,
                    title=nome,
                    description=(
                        f"Valor: R${preco:.2f} | "
                        f"Estoque: {estoque}"
                    ),
                    caption=legenda,
                    parse_mode="Markdown",
                    reply_markup=botao,
                )
            )
        elif imagem_url:
            # Imagem enviada direto pelo Telegram
            # (file_id) — mais confiável que link.
            resultados.append(
                InlineQueryResultCachedPhoto(
                    id=str(produto_id),
                    photo_file_id=imagem_url,
                    title=nome,
                    description=(
                        f"Valor: R${preco:.2f} | "
                        f"Estoque: {estoque}"
                    ),
                    caption=legenda,
                    parse_mode="Markdown",
                    reply_markup=botao,
                )
            )
        else:
            # Sem imagem configurada: mantém o resultado
            # em texto simples, sem foto.
            resultados.append(
                InlineQueryResultArticle(
                    id=str(produto_id),
                    title=nome,
                    description=(
                        f"Valor: R${preco:.2f} | "
                        f"Estoque: {estoque}"
                    ),
                    input_message_content=(
                        InputTextMessageContent(
                            legenda,
                            parse_mode="Markdown",
                        )
                    ),
                    reply_markup=botao,
                )
            )

    try:
        await inline_query.answer(
            resultados,
            cache_time=1,
            is_personal=True,
        )
    except Exception as erro:
        log_erro(
            "ERRO NA BUSCA INLINE:",
            repr(erro),
        )


# =========================================================
# SUPORTE (TICKET)
# =========================================================

async def pedir_suporte(
    query,
    context,
):

    context.user_data["aguardando_suporte"] = True
    context.user_data["aguardando_quantidade"] = False
    context.user_data["aguardando_valor"] = False
    context.user_data["aguardando_pesquisa"] = False

    await editar_ou_substituir(
        query,
        context,
        "🆘 *SUPORTE*\n\n"
        "Descreva o seu problema com clareza.\n\n"
        "📌 Lembre-se de enviar:\n"
        "• 📸 Print do erro\n"
        "• 🔑 Login exatamente como recebido\n"
        "• 📅 Data da compra\n\n"
        "Você pode mandar tudo em uma mensagem só "
        "(inclusive com foto). Nossa equipe "
        "responde por aqui mesmo, em até 24-48h.",
        reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(
                        "❌ Cancelar",
                        callback_data="voltar_menu",
                    )
                ]
            ]
        ),
        parse_mode="Markdown",
    )


async def processar_suporte(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
):

    if not context.user_data.get("aguardando_suporte"):
        return False

    if not update.message:
        return True

    usuario = update.effective_user

    if not usuario:
        return True

    context.user_data["aguardando_suporte"] = False

    nome = usuario.first_name or "cliente"
    username_texto = (
        f"@{usuario.username}"
        if usuario.username
        else "Não informado"
    )

    grupo_suporte_id = obter_configuracao(
        "suporte_grupo_id"
    )

    grupo_suporte_ativo = (
        obter_configuracao("grupo_suporte_ativo", "1")
        == "1"
    )

    # -----------------------------------------------------
    # CAMINHO 1: GRUPO DE SUPORTE COM TÓPICOS (HELPDESK)
    # -----------------------------------------------------

    if grupo_suporte_id and grupo_suporte_ativo:

        try:
            grupo_id_int = int(grupo_suporte_id)
        except ValueError:
            grupo_id_int = None

        if grupo_id_int:

            topico_id = obter_topico_suporte(
                usuario.id
            )

            for tentativa in (1, 2):

                try:

                    if not topico_id:

                        nome_topico = (
                            f"{nome} "
                            f"(@{usuario.username or 'sem_user'}) "
                            f"#{usuario.id}"
                        )

                        topico = await context.bot.create_forum_topic(
                            chat_id=grupo_id_int,
                            name=nome_topico[:128],
                        )

                        topico_id = (
                            topico.message_thread_id
                        )

                        salvar_topico_suporte(
                            usuario.id,
                            topico_id,
                        )

                        await context.bot.send_message(
                            chat_id=grupo_id_int,
                            message_thread_id=topico_id,
                            text=(
                                "📩 *NOVO TICKET*\n\n"
                                f"👤 Nome: {nome}\n"
                                f"🔗 Username: {username_texto}\n"
                                f"🆔 ID: `{usuario.id}`\n\n"
                                "Responda direto aqui neste "
                                "tópico — a mensagem vai "
                                "pro cliente automaticamente."
                            ),
                            parse_mode="Markdown",
                        )

                    await update.message.forward(
                        chat_id=grupo_id_int,
                        message_thread_id=topico_id,
                    )

                    await update.message.reply_text(
                        "✅ *Mensagem enviada ao suporte!*\n\n"
                        "Nossa equipe vai responder por "
                        "aqui mesmo assim que possível.",
                        reply_markup=InlineKeyboardMarkup(
                            [
                                [
                                    InlineKeyboardButton(
                                        "↩️ Voltar ao menu",
                                        callback_data="voltar_menu",
                                    )
                                ]
                            ]
                        ),
                        parse_mode="Markdown",
                    )

                    return True

                except Exception as erro:

                    erro_texto = str(erro).lower()

                    topico_invalido = (
                        "thread not found" in erro_texto
                        or "topic_closed" in erro_texto
                        or "topic_deleted" in erro_texto
                    )

                    if (
                        topico_invalido
                        and tentativa == 1
                        and topico_id
                    ):
                        # O tópico salvo não existe mais
                        # no grupo (foi apagado/recriado).
                        # Limpa e tenta de novo criando um
                        # tópico novo.
                        remover_topico_suporte(
                            usuario.id
                        )
                        topico_id = None
                        continue

                    log_erro(
                        "ERRO NO GRUPO DE SUPORTE COM "
                        "TÓPICOS:",
                        repr(erro),
                    )
                    # Cai pro caminho antigo abaixo.
                    break

    # -----------------------------------------------------
    # CAMINHO 2 (FALLBACK): CHAT INDIVIDUAL
    # -----------------------------------------------------

    texto_info = (
        "📩 *NOVO TICKET DE SUPORTE*\n\n"
        f"👤 Nome: {nome}\n"
        f"🔗 Username: {username_texto}\n"
        f"🆔 ID do cliente: `{usuario.id}`\n\n"
        "↩️ Para responder, dê *Reply* nesta "
        "mensagem com a resposta (texto ou foto)."
    )

    chat_suporte_ativo = (
        obter_configuracao("chat_suporte_ativo", "1")
        == "1"
    )

    destino = (
        obter_configuracao("suporte_chat_id")
        if chat_suporte_ativo
        else None
    ) or ADMIN_ID

    try:
        await update.message.forward(
            chat_id=destino
        )

        await context.bot.send_message(
            chat_id=destino,
            text=texto_info,
            parse_mode="Markdown",
        )

    except Exception as erro:
        log_erro(
            "ERRO AO ENCAMINHAR TICKET DE SUPORTE:",
            repr(erro),
        )

        await update.message.reply_text(
            "❌ Não foi possível enviar sua "
            "mensagem ao suporte agora. Tente "
            "novamente em instantes."
        )

        return True

    await update.message.reply_text(
        "✅ *Mensagem enviada ao suporte!*\n\n"
        "Nossa equipe vai responder por aqui "
        "mesmo assim que possível.",
        reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(
                        "↩️ Voltar ao menu",
                        callback_data="voltar_menu",
                    )
                ]
            ]
        ),
        parse_mode="Markdown",
    )

    return True


# =========================================================
# COMANDO /pix (ATALHO PRA ADICIONAR SALDO)
# =========================================================

async def comando_pix(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
):

    usuario = update.effective_user

    if not usuario or not update.message:
        return

    if modo_manutencao_ativo() and not eh_admin_principal(
        usuario.id
    ):
        await update.message.reply_text(
            TEXTO_MANUTENCAO,
            parse_mode="Markdown",
        )
        return

    context.user_data["aguardando_valor"] = True
    context.user_data["valor_saldo"] = None
    context.user_data["aguardando_quantidade"] = False
    context.user_data["produto_quantidade_id"] = None

    await update.message.reply_text(
        "💵 *ADICIONAR SALDO*\n\n"
        "💠 PIX AUTOMÁTICO\n\n"
        "Digite o valor que deseja adicionar.\n\n"
        f"▫️ Mínimo: R$ {VALOR_MINIMO:.2f}\n"
        f"▫️ Máximo: R$ {VALOR_MAXIMO:.2f}\n\n"
        "Exemplo:\n"
        "`10`\n"
        "`25,50`\n"
        "`100`",
        reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(
                        "⬅️ Voltar",
                        callback_data="voltar_menu",
                    )
                ]
            ]
        ),
        parse_mode="Markdown",
    )


# =========================================================
# COMANDO /id (MOSTRA O ID DO TELEGRAM)
# =========================================================

async def comando_id(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
):

    usuario = update.effective_user

    if not usuario or not update.message:
        return

    await update.message.reply_text(
        "🆔 *SEU ID DO TELEGRAM*\n\n"
        f"`{usuario.id}`",
        parse_mode="Markdown",
    )


# =========================================================
# COMANDO /grupoid (AJUDA A CONFIGURAR O GRUPO DE SUPORTE)
# =========================================================

async def comando_grupo_id(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
):

    if not update.effective_chat:
        return

    await update.message.reply_text(
        "🆔 *ID deste chat:*\n"
        f"`{update.effective_chat.id}`\n\n"
        "Cole esse número no painel admin, em "
        "\"🗂️ GRUPO DE SUPORTE (TÓPICOS)\".",
        parse_mode="Markdown",
    )


# =========================================================
# COMANDO /cadastrarlote (SÓ ADMIN) — CADASTRO EM MASSA
# =========================================================
# Comando de uso único: cadastra de uma vez a lista de
# produtos que o admin pediu, todos com preço 0 (pra ele
# ajustar o preço de cada um depois, no painel normal) e
# já na categoria "Contas". Pode rodar mais de uma vez sem
# duplicar — pula quem já existe com o mesmo nome.

NOMES_LOTE_CONTAS = [
    "CONTA CLARO TV + TELECINE",
    "CONTA CLARO TV + TELECINE + HBO",
    "CONTA DISNEY PADRÃO COM ANUNCIO",
    "CONTA GLOBOPLAY + CANAIS",
    "CONTA GLOBOPLAY + CANAIS + PREMIERE",
    "CONTA GLOBOPLAY + CANAIS + TELECINE",
    "CONTA MAX BASICA COM ANUNCIO",
    "CONTA MAX PLATINIUM",
    "CONTA NETFLIX 4K",
    "CONTA PRIME VIDEO + MAX",
    "CONTA PRIME VIDEO + PREMIERE",
    "CONTA PRIME VIDEO 8 ADICIONAIS",
    "CONTA SKY+ COMPLETA",
]


async def comando_cadastrarlote(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
):

    usuario = update.effective_user

    if not usuario or not update.message:
        return

    if not eh_admin_principal(usuario.id):
        return

    if update.effective_chat.type != "private":

        await update.message.reply_text(
            "❌ Use esse comando no privado com o bot."
        )

        return

    existentes = {
        p[1].strip().lower()
        for p in _listar_produtos_lote()
    }

    categoria = _buscar_categoria_lote("Contas")
    categoria_id = categoria[0] if categoria else None

    criados = []
    pulados = []

    for nome in NOMES_LOTE_CONTAS:

        if nome.strip().lower() in existentes:
            pulados.append(nome)
            continue

        produto_id = _cadastrar_produto_lote(
            nome,
            "",
            0,
            0,
        )

        if categoria_id:
            _definir_categoria_lote(
                produto_id,
                categoria_id,
            )

        criados.append(nome)

    texto = (
        "📦 *CADASTRO EM LOTE CONCLUÍDO*\n\n"
        f"✅ Criados ({len(criados)}):\n"
    )

    texto += (
        "\n".join(f"• {n}" for n in criados)
        if criados
        else "—"
    )

    if pulados:

        texto += (
            f"\n\n⏭️ Já existiam, pulados "
            f"({len(pulados)}):\n"
        )

        texto += "\n".join(f"• {n}" for n in pulados)

    texto += (
        "\n\n⚠️ Todos entraram com preço R$ 0,00 e sem "
        "estoque. Ajuste o preço e adicione as contas de "
        "cada um pelo painel admin normal."
    )

    await update.message.reply_text(
        texto,
        parse_mode="Markdown",
    )


# =========================================================
# COMANDO /backup (SÓ ADMIN) — MANDA O bot.db NO CHAT
# =========================================================

async def comando_backup(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
):

    usuario = update.effective_user

    if not usuario or not update.message:
        return

    if not eh_admin_principal(usuario.id):
        return

    if update.effective_chat.type != "private":

        await update.message.reply_text(
            "❌ Por segurança, o /backup só funciona "
            "no seu chat privado com o bot (ele manda "
            "o banco inteiro, com senhas e saldo dos "
            "clientes). Chame de novo aqui no privado."
        )

        return

    from config import DATABASE_NAME
    import os as _os

    if not _os.path.exists(DATABASE_NAME):
        await update.message.reply_text(
            "❌ Arquivo do banco não encontrado "
            f"em `{DATABASE_NAME}`.",
            parse_mode="Markdown",
        )
        return

    try:
        with open(DATABASE_NAME, "rb") as arquivo:
            await update.message.reply_document(
                document=arquivo,
                filename="bot.db",
                caption=(
                    "💾 *BACKUP DO BANCO DE DADOS*\n\n"
                    "Guarde esse arquivo em local seguro. "
                    "Pra restaurar, basta colocá-lo na "
                    "pasta do bot com o mesmo nome "
                    "(`bot.db`) antes de iniciar."
                ),
                parse_mode="Markdown",
            )
    except Exception as erro:
        log_erro(
            "ERRO AO ENVIAR BACKUP:",
            repr(erro),
        )
        await update.message.reply_text(
            "❌ Não foi possível enviar o backup."
        )


# =========================================================
# RESPONDER SUPORTE DE DENTRO DO GRUPO (TÓPICOS)
# =========================================================

async def responder_suporte_topico(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
):

    mensagem = update.message

    if not mensagem:
        return

    grupo_suporte_id = obter_configuracao(
        "suporte_grupo_id"
    )

    if not grupo_suporte_id:
        return

    try:
        if int(grupo_suporte_id) != int(
            mensagem.chat_id
        ):
            return
    except (ValueError, TypeError):
        return

    topico_id = mensagem.message_thread_id

    if not topico_id:
        return

    cliente_id = obter_usuario_por_topico(
        topico_id
    )

    if not cliente_id:
        return

    try:
        if mensagem.text:

            await context.bot.send_message(
                chat_id=cliente_id,
                text=(
                    "💬 *Resposta do suporte:*\n\n"
                    f"{mensagem.text}"
                ),
                parse_mode="Markdown",
            )

        elif mensagem.photo:

            legenda = mensagem.caption or ""

            await context.bot.send_photo(
                chat_id=cliente_id,
                photo=mensagem.photo[-1].file_id,
                caption=(
                    "💬 *Resposta do suporte:*\n\n"
                    f"{legenda}"
                ),
                parse_mode="Markdown",
            )

        else:
            return

    except Exception as erro:
        log_erro(
            "ERRO AO RESPONDER TICKET (TÓPICO):",
            repr(erro),
        )

        try:
            await mensagem.reply_text(
                "❌ Não foi possível entregar a "
                "resposta (o cliente pode ter "
                "bloqueado o bot)."
            )
        except Exception:
            pass


async def responder_suporte_admin(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
):

    usuario = update.effective_user

    if not usuario:
        return

    destino_configurado = obter_configuracao(
        "suporte_chat_id"
    )

    contas_autorizadas = {
        str(ADMIN_ID)
    }

    if destino_configurado:
        contas_autorizadas.add(
            str(destino_configurado)
        )

    if str(usuario.id) not in contas_autorizadas:
        return

    mensagem = update.message

    if not mensagem or not mensagem.reply_to_message:
        return

    texto_original = (
        mensagem.reply_to_message.text or ""
    )

    correspondencia = re.search(
        r"ID do cliente:\s*`?(\d+)`?",
        texto_original,
    )

    if not correspondencia:
        return

    cliente_id = int(
        correspondencia.group(1)
    )

    try:
        if mensagem.text:

            await context.bot.send_message(
                chat_id=cliente_id,
                text=(
                    "💬 *Resposta do suporte:*\n\n"
                    f"{mensagem.text}"
                ),
                parse_mode="Markdown",
            )

        elif mensagem.photo:

            legenda = mensagem.caption or ""

            await context.bot.send_photo(
                chat_id=cliente_id,
                photo=mensagem.photo[-1].file_id,
                caption=(
                    "💬 *Resposta do suporte:*\n\n"
                    f"{legenda}"
                ),
                parse_mode="Markdown",
            )

        else:
            return

        await mensagem.reply_text(
            "✅ Resposta enviada ao cliente."
        )

    except Exception as erro:
        log_erro(
            "ERRO AO RESPONDER TICKET DE SUPORTE:",
            repr(erro),
        )

        await mensagem.reply_text(
            "❌ Não foi possível enviar a resposta "
            "ao cliente (ele pode ter bloqueado "
            "o bot)."
        )


# =========================================================
# RENOVAR CONTA (HISTÓRICO + RENOVAÇÃO)
# =========================================================

DIAS_GRACA_RENOVACAO = 7


async def mostrar_historico_renovacao(
    query,
    context,
    usuario_id,
):

    contas = listar_contas_usuario(
        usuario_id
    )

    if not contas:
        await editar_ou_substituir(
            query,
            context,
            "♻️ *RENOVAR CONTA*\n\n"
            "Você ainda não tem contas compradas.\n\n"
            "Aparecem aqui as contas que você "
            "comprou, desde a compra até um "
            "pouco depois do vencimento.",
            reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(
                            "🛒 Ver catálogo",
                            callback_data="catalogo",
                        )
                    ],
                    [
                        InlineKeyboardButton(
                            "↩️ Voltar ao menu",
                            callback_data="voltar_menu",
                        )
                    ],
                ]
            ),
            parse_mode="Markdown",
        )
        return

    agora = datetime.now()

    texto = (
        "♻️ *RENOVAR CONTA*\n\n"
        "Histórico das suas contas:\n\n"
    )

    botoes = []

    for conta in contas[:20]:

        (
            login_id,
            produto_id,
            nome_produto,
            vendido_em,
            duracao_dias,
        ) = conta

        try:
            data_compra = datetime.strptime(
                vendido_em[:19],
                "%Y-%m-%d %H:%M:%S",
            )
        except (ValueError, TypeError):
            data_compra = None

        data_texto = (
            data_compra.strftime("%d/%m/%Y")
            if data_compra
            else "Data desconhecida"
        )

        if not duracao_dias or not data_compra:

            texto += (
                f"📦 *{nome_produto}*\n"
                f"🗓️ Comprado em: {data_texto}\n"
                "ℹ️ Duração não cadastrada\n\n"
            )
            continue

        vencimento = data_compra + timedelta(
            days=duracao_dias
        )

        dias_restantes = (
            vencimento - agora
        ).days

        if dias_restantes >= 0:

            status = (
                f"✅ Ativo (vence em "
                f"{dias_restantes}d)"
            )

            elegivel = True

        else:

            dias_vencido = abs(
                dias_restantes
            )

            if dias_vencido <= DIAS_GRACA_RENOVACAO:

                status = (
                    f"🔴 Vencido há "
                    f"{dias_vencido}d"
                )

                elegivel = True

            else:

                status = (
                    f"⚫ Vencido há "
                    f"{dias_vencido}d"
                )

                elegivel = False

        texto += (
            f"📦 *{nome_produto}*\n"
            f"🗓️ Comprado em: {data_texto}\n"
            f"{status}\n\n"
        )

        if elegivel:

            botoes.append(
                [
                    InlineKeyboardButton(
                        f"🔁 Renovar {nome_produto[:30]}",
                        callback_data=(
                            f"renovar_login_{login_id}"
                        ),
                    )
                ]
            )

    if len(contas) > 20:
        texto += (
            "_Mostrando as 20 compras mais "
            "recentes._\n\n"
        )

    botoes.append(
        [
            InlineKeyboardButton(
                "↩️ Voltar ao menu",
                callback_data="voltar_menu",
            )
        ]
    )

    await editar_ou_substituir(
        query,
        context,
        texto,
        reply_markup=InlineKeyboardMarkup(
            botoes
        ),
        parse_mode="Markdown",
    )


async def renovar_conta(
    query,
    context,
    usuario_id,
    login_id,
):

    login = consultar_login(
        login_id
    )

    if not login:
        await query.answer(
            "❌ Conta não encontrada.",
            show_alert=True,
        )
        return

    (
        _,
        produto_id,
        _dados,
        _status,
        login_usuario_id,
        _pedido_id,
        _vendido_em,
    ) = login

    if int(login_usuario_id or 0) != int(
        usuario_id
    ):
        await query.answer(
            "❌ Essa conta não é sua.",
            show_alert=True,
        )
        return

    await comprar_produto(
        query,
        context,
        produto_id,
        usuario_id,
        1,
    )


# =========================================================
# HISTÓRICO DE COMPRAS
# =========================================================

async def mostrar_historico_compras(
    query,
    context,
    pagina=0,
):
    usuario_id = query.from_user.id

    POR_PAGINA = 10

    pedidos, total = listar_pedidos_cliente(
        usuario_id,
        pagina=pagina,
        por_pagina=POR_PAGINA,
    )

    if total == 0:
        await editar_ou_substituir(
            query,
            context,
            "📜 *HISTÓRICO DE COMPRAS*\n\n"
            "Você ainda não fez nenhuma compra.",
            reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(
                            "⬅️ VOLTAR AO MENU",
                            callback_data="voltar_menu",
                        )
                    ]
                ]
            ),
            parse_mode="Markdown",
        )
        return

    total_paginas = max(
        1,
        (total + POR_PAGINA - 1) // POR_PAGINA,
    )

    pagina_atual = max(
        0, min(pagina, total_paginas - 1)
    )

    linhas_botoes = []

    for (
        pedido_id,
        nome_produto,
        quantidade,
        valor,
        criado_em,
    ) in pedidos:

        data_formatada = str(criado_em)[:10]

        linhas_botoes.append([
            InlineKeyboardButton(
                f"{data_formatada} — {nome_produto} "
                f"(R$ {float(valor):.2f})",
                callback_data=(
                    f"ver_pedido_{pedido_id}"
                ),
            )
        ])

    botoes_navegacao = []

    if pagina_atual > 0:
        botoes_navegacao.append(
            InlineKeyboardButton(
                "⬅️ Anterior",
                callback_data=(
                    "historico_compras_"
                    f"{pagina_atual - 1}"
                ),
            )
        )

    if pagina_atual < total_paginas - 1:
        botoes_navegacao.append(
            InlineKeyboardButton(
                "Próxima ➡️",
                callback_data=(
                    "historico_compras_"
                    f"{pagina_atual + 1}"
                ),
            )
        )

    if botoes_navegacao:
        linhas_botoes.append(botoes_navegacao)

    linhas_botoes.append([
        InlineKeyboardButton(
            "⬅️ VOLTAR AO MENU",
            callback_data="voltar_menu",
        )
    ])

    await editar_ou_substituir(
        query,
        context,
        "📜 *HISTÓRICO DE COMPRAS*\n\n"
        f"🛍️ Total: {total} compra(s)\n"
        f"📄 Página {pagina_atual + 1} de "
        f"{total_paginas}\n\n"
        "Toque em uma compra pra ver os dados "
        "de acesso novamente:",
        reply_markup=InlineKeyboardMarkup(
            linhas_botoes
        ),
        parse_mode="Markdown",
    )


async def mostrar_detalhes_pedido(
    query,
    context,
    pedido_id,
):
    usuario_id = query.from_user.id

    detalhes = obter_detalhes_pedido(
        pedido_id,
        usuario_id,
    )

    if not detalhes:
        await query.answer(
            "❌ Pedido não encontrado.",
            show_alert=True,
        )
        return

    texto_contas = ""

    for indice, dados in enumerate(
        detalhes["contas"], start=1
    ):
        texto_contas += (
            f"\n🔐 *Conta {indice}*\n"
            f"```\n{dados}\n```\n"
        )

    if not texto_contas:
        texto_contas = (
            "\n⚠️ Nenhum dado de acesso "
            "encontrado pra essa compra — "
            "fale com o suporte se precisar "
            "de ajuda.\n"
        )

    data_formatada = str(
        detalhes["criado_em"]
    )[:16]

    await editar_ou_substituir(
        query,
        context,
        "🧾 *DETALHES DA COMPRA*\n\n"
        "━━━━━━━━━━━━━━━━━━\n"
        f"🛒 *Produto:* "
        f"{detalhes['nome_produto']}\n"
        f"📦 *Quantidade:* "
        f"{detalhes['quantidade']}\n"
        f"💵 *Valor pago:* "
        f"R$ {float(detalhes['valor']):.2f}\n"
        f"📅 *Data:* {data_formatada}\n"
        "━━━━━━━━━━━━━━━━━━\n"
        "🎁 *DADOS DE ACESSO*"
        f"{texto_contas}",
        reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(
                        "⬅️ VOLTAR AO HISTÓRICO",
                        callback_data=(
                            "historico_compras_0"
                        ),
                    )
                ]
            ]
        ),
        parse_mode="Markdown",
    )


# =========================================================
# JOGOS NA TV
# =========================================================

async def mostrar_jogos_tv(
    query,
    context,
):

    jogos_texto = obter_configuracao(
        "jogos_tv_texto"
    )

    if not jogos_texto:
        texto = (
            "⚽ *JOGOS NA TV*\n\n"
            "❌ Nenhum jogo cadastrado no momento."
        )
    else:
        texto = (
            "⚽ *JOGOS NA TV*\n\n"
            f"{jogos_texto}"
        )

    await editar_ou_substituir(
        query,
        context,
        texto,
        reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(
                        "↩️ Voltar ao menu",
                        callback_data="voltar_menu",
                    )
                ]
            ]
        ),
        parse_mode="Markdown",
    )


# =========================================================
# PESQUISAR SERVIÇO
# =========================================================

async def pedir_pesquisa_servico(
    query,
    context,
):

    context.user_data["aguardando_pesquisa"] = True
    context.user_data["aguardando_quantidade"] = False
    context.user_data["aguardando_valor"] = False
    context.user_data["produto_quantidade_id"] = None

    await editar_ou_substituir(
        query,
        context,
        "🔎 *PESQUISAR SERVIÇO*\n\n"
        "Digite o nome do produto que você "
        "está procurando.\n\n"
        "Exemplo:\n"
        "`netflix`\n"
        "`disney`",
        reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(
                        "⬅️ Voltar",
                        callback_data="voltar_menu",
                    )
                ]
            ]
        ),
        parse_mode="Markdown",
    )


async def processar_pesquisa_servico(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
):

    if not update.message:
        return

    termo = (update.message.text or "").strip()

    if not termo:

        await update.message.reply_text(
            "❌ Digite um termo para pesquisar."
        )
        return

    context.user_data["aguardando_pesquisa"] = False

    produtos = buscar_produtos_por_nome(
        termo
    )

    if not produtos:

        await update.message.reply_text(
            "🔎 *PESQUISAR SERVIÇO*\n\n"
            f"❌ Nenhum resultado para: "
            f"\"{termo}\"",
            reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(
                            "🔎 Pesquisar de novo",
                            callback_data="pesquisar_servico",
                        )
                    ],
                    [
                        InlineKeyboardButton(
                            "🛒 Ver catálogo",
                            callback_data="catalogo",
                        )
                    ],
                    [
                        InlineKeyboardButton(
                            "↩️ Voltar ao menu",
                            callback_data="voltar_menu",
                        )
                    ],
                ]
            ),
            parse_mode="Markdown",
        )
        return

    botoes = []

    for produto in produtos:

        produto_id = produto[0]
        nome = produto[1]
        preco = float(produto[3])

        botoes.append(
            [
                InlineKeyboardButton(
                    f"{nome} R${preco:.2f}",
                    callback_data=(
                        f"produto_{produto_id}"
                    ),
                )
            ]
        )

    botoes.append(
        [
            InlineKeyboardButton(
                "🔎 Pesquisar de novo",
                callback_data="pesquisar_servico",
            )
        ]
    )

    botoes.append(
        [
            InlineKeyboardButton(
                "↩️ Voltar ao menu",
                callback_data="voltar_menu",
            )
        ]
    )

    await update.message.reply_text(
        "🔎 *RESULTADO DA PESQUISA*\n\n"
        f"Encontrado(s) {len(produtos)} "
        f"resultado(s) para \"{termo}\":",
        reply_markup=InlineKeyboardMarkup(
            botoes
        ),
        parse_mode="Markdown",
    )


# =========================================================
# CARRINHO
# =========================================================

async def mostrar_carrinho(
    query,
    context,
    usuario_id,
):

    itens = listar_itens_carrinho(
        usuario_id
    )

    if not itens:

        await editar_ou_substituir(
            query,
            context,
            "🛍️ *CARRINHO*\n\n"
            "Seu carrinho está vazio.\n\n"
            "Adicione produtos pelo catálogo.",
            reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(
                            "🛒 Ver catálogo",
                            callback_data="catalogo",
                        )
                    ],
                    [
                        InlineKeyboardButton(
                            "↩️ Voltar ao menu",
                            callback_data="voltar_menu",
                        )
                    ],
                ]
            ),
            parse_mode="Markdown",
        )
        return

    texto = (
        "🛍️ *CARRINHO*\n\n"
        "━━━━━━━━━━━━━━━━━━\n"
    )

    total = 0.0
    botoes = []

    for item in itens:

        item_id, produto_id, nome, preco, quantidade = item

        preco = float(preco)
        quantidade = int(quantidade)
        subtotal = preco * quantidade
        total += subtotal

        texto += (
            f"📦 *{nome}*\n"
            f"   {quantidade}x R$ {preco:.2f} = "
            f"R$ {subtotal:.2f}\n\n"
        )

        botoes.append(
            [
                InlineKeyboardButton(
                    f"🗑️ Remover {nome[:25]}",
                    callback_data=(
                        f"remover_carrinho_{item_id}"
                    ),
                )
            ]
        )

    saldo = float(
        consultar_saldo(usuario_id) or 0
    )

    texto += (
        "━━━━━━━━━━━━━━━━━━\n\n"
        f"💰 *Total:* R$ {total:.2f}\n"
        f"💳 *Seu saldo:* R$ {saldo:.2f}"
    )

    botoes.append(
        [
            InlineKeyboardButton(
                "✅ FINALIZAR COMPRA",
                callback_data="finalizar_carrinho",
            )
        ]
    )

    botoes.append(
        [
            InlineKeyboardButton(
                "🗑️ ESVAZIAR CARRINHO",
                callback_data="esvaziar_carrinho",
            )
        ]
    )

    botoes.append(
        [
            InlineKeyboardButton(
                "🛒 Ver catálogo",
                callback_data="catalogo",
            )
        ]
    )

    botoes.append(
        [
            InlineKeyboardButton(
                "↩️ Voltar ao menu",
                callback_data="voltar_menu",
            )
        ]
    )

    await editar_ou_substituir(
        query,
        context,
        texto,
        reply_markup=InlineKeyboardMarkup(
            botoes
        ),
        parse_mode="Markdown",
    )


async def finalizar_compra_carrinho(
    query,
    context,
    usuario_id,
):

    itens = listar_itens_carrinho(
        usuario_id
    )

    if not itens:

        await query.answer(
            "🛍️ Seu carrinho está vazio.",
            show_alert=True,
        )
        return

    # ---------------------------------------------------
    # Confere estoque real de cada item antes de cobrar.
    # ---------------------------------------------------

    itens_insuficientes = []
    total = 0.0

    for item in itens:

        _, produto_id, nome, preco, quantidade = item

        preco = float(preco)
        quantidade = int(quantidade)

        estoque_real = consultar_estoque_logins(
            produto_id
        )

        if estoque_real < quantidade:

            itens_insuficientes.append(
                f"📦 {nome} "
                f"(disponível: {estoque_real}, "
                f"pedido: {quantidade})"
            )

        total += preco * quantidade

    if itens_insuficientes:

        texto_erro = (
            "❌ *ESTOQUE INSUFICIENTE*\n\n"
            "Os itens abaixo não têm estoque "
            "suficiente:\n\n"
            + "\n".join(itens_insuficientes)
            + "\n\nAjuste as quantidades no carrinho "
            "e tente novamente."
        )

        await editar_ou_substituir(
            query,
            context,
            texto_erro,
            reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(
                            "🛍️ Voltar ao carrinho",
                            callback_data="carrinho",
                        )
                    ]
                ]
            ),
            parse_mode="Markdown",
        )
        return

    saldo = float(
        consultar_saldo(usuario_id) or 0
    )

    if saldo < total:

        await editar_ou_substituir(
            query,
            context,
            "❌ *SALDO INSUFICIENTE*\n\n"
            f"💰 *Total do carrinho:* R$ {total:.2f}\n"
            f"💳 *Seu saldo:* R$ {saldo:.2f}\n"
            f"💵 *Faltam:* R$ {total - saldo:.2f}",
            reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(
                            "💵 ADICIONAR SALDO",
                            callback_data="adicionar_saldo",
                        )
                    ],
                    [
                        InlineKeyboardButton(
                            "🛍️ Voltar ao carrinho",
                            callback_data="carrinho",
                        )
                    ],
                ]
            ),
            parse_mode="Markdown",
        )
        return

    sucesso = retirar_saldo(
        usuario_id,
        total,
    )

    if not sucesso:

        await query.answer(
            "❌ Não foi possível processar o pagamento.",
            show_alert=True,
        )
        return

    entregas = []
    falhou = False
    pedidos_criados = []

    for item in itens:

        _, produto_id, nome, preco, quantidade = item

        preco = float(preco)
        quantidade = int(quantidade)
        valor_item = preco * quantidade

        pedido_id = None

        try:
            conn = conectar()
            cursor = conn.cursor()

            cursor.execute(
                """
                INSERT INTO pedidos
                (
                    usuario_id,
                    produto_id,
                    quantidade,
                    valor,
                    status
                )
                VALUES (?, ?, ?, ?, 'pago')
                """,
                (
                    usuario_id,
                    produto_id,
                    quantidade,
                    valor_item,
                ),
            )

            pedido_id = cursor.lastrowid
            conn.commit()
            conn.close()

            pedidos_criados.append(pedido_id)

        except Exception as erro:
            log_erro(
                "ERRO AO REGISTRAR PEDIDO DO CARRINHO:",
                repr(erro),
            )
            falhou = True
            break

        contas_produto = []

        for _ in range(quantidade):

            login = retirar_login_disponivel(
                produto_id,
                usuario_id,
                pedido_id,
            )

            if not login:
                falhou = True
                break

            contas_produto.append(
                login["dados"]
            )

        if falhou:
            break

        entregas.append(
            {
                "nome": nome,
                "quantidade": quantidade,
                "preco_unitario": preco,
                "contas": contas_produto,
            }
        )

        await verificar_estoque_baixo(
            context.bot,
            produto_id,
            nome,
        )

        await anunciar_venda_grupo(
            context.bot,
            nome,
            preco,
            quantidade,
            nome_cliente=query.from_user.first_name,
            usuario_id=usuario_id,
        )

    if falhou:

        try:
            conn = conectar()
            cursor = conn.cursor()
            for pedido_id_falho in pedidos_criados:
                cursor.execute(
                    """
                    UPDATE pedidos
                    SET status = 'cancelado'
                    WHERE id = ?
                    """,
                    (pedido_id_falho,),
                )
            conn.commit()
            conn.close()
        except Exception as erro_db:
            log_erro(
                "ERRO AO CANCELAR PEDIDOS DO CARRINHO:",
                repr(erro_db),
            )

        for pedido_id_falho in pedidos_criados:
            try:
                liberar_logins_pedido(pedido_id_falho)
            except Exception as erro_liberar:
                log_erro(
                    "ERRO AO LIBERAR LOGINS DO CARRINHO:",
                    repr(erro_liberar),
                )

        adicionar_saldo(
            usuario_id,
            total,
        )

        await editar_ou_substituir(
            query,
            context,
            "❌ *COMPRA NÃO CONCLUÍDA*\n\n"
            "O estoque de algum item acabou "
            "durante o processamento.\n\n"
            "💰 O valor foi devolvido ao seu saldo.\n"
            "Confira o carrinho e tente novamente.",
            reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(
                            "🛍️ Ver carrinho",
                            callback_data="carrinho",
                        )
                    ]
                ]
            ),
            parse_mode="Markdown",
        )
        return

    limpar_carrinho(
        usuario_id
    )

    novo_saldo = float(
        consultar_saldo(usuario_id) or 0
    )

    texto = montar_mensagem_compra_realizada(
        itens=entregas,
        total=total,
        novo_saldo=novo_saldo,
    )

    await editar_ou_substituir(
        query,
        context,
        texto,
        reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(
                        "🛒 Ver catálogo",
                        callback_data="catalogo",
                    )
                ],
                [
                    InlineKeyboardButton(
                        "↩️ Voltar ao menu",
                        callback_data="voltar_menu",
                    )
                ],
            ]
        ),
        parse_mode="Markdown",
    )


# =========================================================
# EDITAR TEXTO (COM SUPORTE A MENSAGENS QUE SÃO FOTO/GIF)
# =========================================================
#
# query.edit_message_text falha quando a mensagem original
# é uma foto ou GIF (como o catálogo com imagem configurada
# pelo admin). Nesses casos, apagamos a mensagem e mandamos
# uma nova mensagem de texto no lugar.

async def editar_ou_substituir(
    query,
    context,
    texto,
    reply_markup=None,
    parse_mode="Markdown",
    imagem_url=None,
):

    mensagem = query.message

    e_midia = bool(
        mensagem
        and (
            mensagem.photo
            or mensagem.animation
        )
    )

    # -----------------------------------------------------
    # COM IMAGEM CONFIGURADA: tenta enviar como foto
    # primeiro; só mexe na mensagem antiga se der certo.
    # -----------------------------------------------------
    if imagem_url:

        try:
            await context.bot.send_photo(
                chat_id=mensagem.chat_id,
                photo=imagem_url,
                caption=texto,
                reply_markup=reply_markup,
                parse_mode=parse_mode,
            )

            if mensagem:
                try:
                    await mensagem.delete()
                except Exception:
                    pass

            return
        except Exception as erro:
            log_erro(
                "ERRO AO ENVIAR FOTO DO PRODUTO:",
                repr(erro),
            )
            # Se a URL falhar (link quebrado, bloqueado
            # etc.), a mensagem antiga continua intacta e
            # cai pro fluxo de texto normal abaixo, em vez
            # de deixar o cliente sem resposta.

    # -----------------------------------------------------
    # SEM IMAGEM (ou falha ao enviar a foto): texto normal
    # -----------------------------------------------------
    if e_midia:

        try:
            await mensagem.delete()
        except Exception:
            pass

        await context.bot.send_message(
            chat_id=mensagem.chat_id,
            text=texto,
            reply_markup=reply_markup,
            parse_mode=parse_mode,
        )

    else:

        await query.edit_message_text(
            texto,
            reply_markup=reply_markup,
            parse_mode=parse_mode,
        )


# =========================================================
# BOTÕES
# =========================================================

async def botoes(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
):
    query = update.callback_query

    if not query:
        return

    try:
        await query.answer()
    except Exception:
        pass

    usuario_id = query.from_user.id
    acao = query.data or ""

    if (
        modo_manutencao_ativo()
        and not eh_admin_principal(usuario_id)
        and not acao.startswith("admin_")
    ):
        await query.answer(
            "🛠️ Bot em manutenção. Tente "
            "novamente em breve.",
            show_alert=True,
        )
        return

    # =====================================================
    # PORTÃO DO GRUPO OBRIGATÓRIO
    # =====================================================

    if acao == "checkjoin":

        link_pendente = (
            await bloqueado_por_grupo_obrigatorio(
                context.bot,
                usuario_id,
            )
        )

        if link_pendente:
            await query.answer(
                "❌ Ainda não encontrei você "
                "no grupo. Entra lá e tenta "
                "de novo.",
                show_alert=True,
            )
            return

        await query.answer(
            "✅ Confirmado!",
        )

        usuario = query.from_user

        criar_usuario(
            usuario.id,
            usuario.first_name or "",
            usuario.username or "",
        )

        await enviar_menu_principal(
            query.message.chat_id,
            context,
            "✅ *Tudo certo!*\n\n"
            "🛒 *PLAYER STORE*\n\n"
            "Escolha uma opção abaixo:",
        )
        return

    if not acao.startswith("admin_"):

        link_pendente = (
            await bloqueado_por_grupo_obrigatorio(
                context.bot,
                usuario_id,
            )
        )

        if link_pendente:
            await mostrar_tela_entrar_grupo(
                query,
                link_pendente,
                e_callback=True,
            )
            return

    # =====================================================
    # RELATÓRIO DE VENDAS SOB DEMANDA (INTERCEPTADO ANTES
    # DE DELEGAR PRO PAINEL ADMIN, POIS A FUNÇÃO VIVE AQUI)
    # =====================================================

    if acao == "admin_relatorio_vendas":

        if not eh_admin_principal(usuario_id):
            await query.answer(
                "❌ Acesso negado.",
                show_alert=True,
            )
            return

        await query.answer(
            "📊 Gerando relatório..."
        )

        await enviar_relatorio_vendas(
            context.bot
        )

        return

    # =====================================================
    # ADMIN
    # =====================================================

    if (
        acao == "admin_menu"
        or acao.startswith("admin_")
    ):
        try:
            await botoes_admin(
                update,
                context,
            )
        except Exception as erro:
            log_erro("ERRO NO PAINEL ADMIN:", repr(erro))
            try:
                await query.answer(
                    "❌ Erro no painel administrativo.",
                    show_alert=True,
                )
            except Exception:
                pass
        return

    # =====================================================
    # STATUS PAGAMENTO
    # =====================================================

    if acao.startswith("status_pagamento_"):
        transacao_id = acao.replace(
            "status_pagamento_",
            "",
            1,
        )

        await mostrar_status_pagamento(
            query,
            transacao_id,
        )
        return

    # =====================================================
    # CONSULTAR PAGAMENTO
    # =====================================================

    if acao.startswith("consultar_pagamento_"):
        transacao_id = acao.replace(
            "consultar_pagamento_",
            "",
            1,
        )

        await verificar_pagamento(
            query,
            context,
            transacao_id,
        )
        return

    # =====================================================
    # ESTOQUE DE LOGINS (PÚBLICO)
    # =====================================================

    if acao == "estoque_logins":
        await mostrar_estoque_logins(
            query,
            context,
        )
        return

    # =====================================================
    # PESQUISAR SERVIÇO
    # =====================================================

    if acao == "pesquisar_servico":
        await pedir_pesquisa_servico(
            query,
            context,
        )
        return

    # =====================================================
    # CARRINHO
    # =====================================================

    if acao == "carrinho":
        await mostrar_carrinho(
            query,
            context,
            usuario_id,
        )
        return

    if acao.startswith("add_carrinho_"):

        try:
            produto_id = int(
                acao.replace(
                    "add_carrinho_",
                    "",
                    1,
                )
            )
        except ValueError:
            await query.answer(
                "❌ Produto inválido.",
                show_alert=True,
            )
            return

        produto = buscar_produto(produto_id)

        if not produto:
            await query.answer(
                "❌ Produto não encontrado.",
                show_alert=True,
            )
            return

        estoque_real = consultar_estoque_logins(
            produto_id
        )

        if estoque_real <= 0:
            await query.answer(
                "📦 Produto sem contas disponíveis.",
                show_alert=True,
            )
            return

        adicionar_item_carrinho(
            usuario_id,
            produto_id,
            1,
        )

        await query.answer(
            "✅ Adicionado ao carrinho!",
            show_alert=True,
        )
        return

    if acao.startswith("remover_carrinho_"):

        try:
            item_id = int(
                acao.replace(
                    "remover_carrinho_",
                    "",
                    1,
                )
            )
        except ValueError:
            await query.answer(
                "❌ Item inválido.",
                show_alert=True,
            )
            return

        remover_item_carrinho(
            item_id,
            usuario_id,
        )

        await query.answer(
            "🗑️ Item removido."
        )

        await mostrar_carrinho(
            query,
            context,
            usuario_id,
        )
        return

    if acao == "esvaziar_carrinho":

        limpar_carrinho(
            usuario_id
        )

        await query.answer(
            "🗑️ Carrinho esvaziado."
        )

        await mostrar_carrinho(
            query,
            context,
            usuario_id,
        )
        return

    if acao == "finalizar_carrinho":

        await finalizar_compra_carrinho(
            query,
            context,
            usuario_id,
        )
        return

    # =====================================================
    # CATÁLOGO (CATEGORIAS)
    # =====================================================

    if acao == "catalogo":
        context.user_data["aguardando_quantidade"] = False
        context.user_data["aguardando_valor"] = False

        texto_catalogo = (
            texto_selecionar_categoria()
        )

        imagem_id = obter_configuracao(
            "imagem_catalogo_id"
        )
        imagem_tipo = obter_configuracao(
            "imagem_catalogo_tipo"
        )

        if imagem_id:

            try:
                await query.message.delete()
            except Exception:
                pass

            try:
                if imagem_tipo == "animation":
                    await context.bot.send_animation(
                        chat_id=usuario_id,
                        animation=imagem_id,
                        caption=texto_catalogo,
                        reply_markup=menu_categorias(),
                        parse_mode="Markdown",
                    )
                else:
                    await context.bot.send_photo(
                        chat_id=usuario_id,
                        photo=imagem_id,
                        caption=texto_catalogo,
                        reply_markup=menu_categorias(),
                        parse_mode="Markdown",
                    )
                return
            except Exception as erro:
                log_erro(
                    "ERRO AO ENVIAR IMAGEM DO CATÁLOGO:",
                    repr(erro),
                )
                await context.bot.send_message(
                    chat_id=usuario_id,
                    text=texto_catalogo,
                    reply_markup=menu_categorias(),
                    parse_mode="Markdown",
                )
                return

        await editar_ou_substituir(
            query,
            context,
            texto_catalogo,
            reply_markup=menu_categorias(),
            parse_mode="Markdown",
        )
        return

    # =====================================================
    # PRODUTOS DE UMA CATEGORIA
    # =====================================================

    if acao.startswith("categoria_"):
        try:
            categoria_id = int(
                acao.split("_", 1)[1]
            )
        except (ValueError, IndexError):
            await query.answer(
                "❌ Categoria inválida.",
                show_alert=True,
            )
            return

        categoria = buscar_categoria(
            categoria_id
        )

        if not categoria:
            await query.answer(
                "❌ Categoria não encontrada.",
                show_alert=True,
            )
            return

        emoji = categoria[2]
        nome_categoria = categoria[1]

        await editar_ou_substituir(
            query,
            context,
            f"{emoji} *{nome_categoria.upper()}*\n\n"
            "Escolha um produto:",
            reply_markup=menu_produtos_categoria(
                categoria_id
            ),
            parse_mode="Markdown",
        )
        return

    # =====================================================
    # PRODUTO
    # =====================================================

    if acao.startswith("produto_"):
        try:
            produto_id = int(
                acao.split("_", 1)[1]
            )
        except (ValueError, IndexError):
            await query.answer(
                "❌ Produto inválido.",
                show_alert=True,
            )
            return

        produto = buscar_produto(produto_id)

        if not produto:
            await query.answer(
                "❌ Produto não encontrado.",
                show_alert=True,
            )
            return

        _, nome, descricao, preco, estoque = produto
        preco = float(preco)

        imagem_url = obter_imagem_produto(
            produto_id
        )

        conn = conectar()
        cursor = conn.cursor()

        try:
            cursor.execute(
                """
                SELECT COUNT(*)
                FROM logins
                WHERE produto_id = ?
                  AND status = 'disponivel'
                """,
                (produto_id,),
            )
            estoque_real = int(cursor.fetchone()[0])
        except Exception as erro:
            log_erro("ERRO AO CONSULTAR ESTOQUE:", repr(erro))
            estoque_real = 0
        finally:
            conn.close()

        if estoque_real <= 0:

            await editar_ou_substituir(
                query,
                context,
                "📦 *ESGOTADO NO MOMENTO*\n\n"
                "━━━━━━━━━━━━━━━━━━\n"
                f"🛍️ *Serviço:* {nome}\n"
                "━━━━━━━━━━━━━━━━━━\n\n"
                f"📝 {descricao or 'Sem descrição'}\n\n"
                "Esse produto está sem contas "
                "disponíveis agora. Quer que eu "
                "te avise assim que voltar ao "
                "estoque?",
                reply_markup=InlineKeyboardMarkup(
                    [
                        [
                            InlineKeyboardButton(
                                "🔔 Avisar quando disponível",
                                callback_data=(
                                    f"avisar_reposicao_{produto_id}"
                                ),
                            )
                        ],
                        [
                            InlineKeyboardButton(
                                "⬅️ VOLTAR À CATEGORIA",
                                callback_data="catalogo",
                            )
                        ],
                        [
                            InlineKeyboardButton(
                                "↩️ VOLTAR AO MENU",
                                callback_data="voltar_menu",
                            )
                        ],
                    ]
                ),
                parse_mode="Markdown",
                imagem_url=imagem_url,
            )
            return

        saldo = float(
            consultar_saldo(usuario_id) or 0
        )

        texto = (
            "🛒 *FINALIZAR COMPRA*\n\n"
            "━━━━━━━━━━━━━━━━━━\n"
            f"🛍️ *Serviço:* {nome}\n"
            f"💰 *Preço:* R$ {preco:.2f}\n"
            f"💳 *Seu saldo:* R$ {saldo:.2f}\n"
            f"📦 *Disponível:* {estoque_real}\n"
            "━━━━━━━━━━━━━━━━━━\n\n"
            f"📝 {descricao or 'Sem descrição'}\n\n"
            "⚡ *Entrega imediata*\n"
            "❌ *Sem reembolso em Pix*\n"
            "👩🏻‍💻 *Suporte completo*"
        )

        botoes_compra = [
            [
                InlineKeyboardButton(
                    "🛒 COMPRAR",
                    callback_data=f"comprar_{produto_id}",
                )
            ],
            [
                InlineKeyboardButton(
                    "🛍️ COMPRAR EM QUANTIDADE",
                    callback_data=f"quantidade_{produto_id}",
                )
            ],
            [
                InlineKeyboardButton(
                    "➕ ADICIONAR AO CARRINHO",
                    callback_data=f"add_carrinho_{produto_id}",
                )
            ],
            [
                InlineKeyboardButton(
                    "💵 ADICIONAR SALDO",
                    callback_data="adicionar_saldo",
                )
            ],
            [
                InlineKeyboardButton(
                    "⬅️ VOLTAR À CATEGORIA",
                    callback_data="catalogo",
                )
            ],
            [
                InlineKeyboardButton(
                    "↩️ VOLTAR AO MENU",
                    callback_data="voltar_menu",
                )
            ],
        ]

        await editar_ou_substituir(
            query,
            context,
            texto,
            reply_markup=InlineKeyboardMarkup(
                botoes_compra
            ),
            parse_mode="Markdown",
            imagem_url=imagem_url,
        )
        return

    # =====================================================
    # AVISAR QUANDO REPOSTO
    # =====================================================

    if acao.startswith("avisar_reposicao_"):

        try:
            produto_id = int(
                acao.replace(
                    "avisar_reposicao_",
                    "",
                    1,
                )
            )
        except ValueError:
            await query.answer(
                "❌ Produto inválido.",
                show_alert=True,
            )
            return

        produto = buscar_produto(produto_id)

        if not produto:
            await query.answer(
                "❌ Produto não encontrado.",
                show_alert=True,
            )
            return

        registrar_aviso_reposicao(
            usuario_id,
            produto_id,
        )

        await query.answer(
            "🔔 Combinado! Você vai receber uma "
            "mensagem assim que esse produto "
            "voltar ao estoque.",
            show_alert=True,
        )
        return

    # =====================================================
    # COMPRAR EM QUANTIDADE
    # =====================================================

    if acao.startswith("quantidade_"):
        try:
            produto_id = int(
                acao.split("_", 1)[1]
            )
        except (ValueError, IndexError):
            await query.answer(
                "❌ Produto inválido.",
                show_alert=True,
            )
            return

        await pedir_quantidade_produto(
            query,
            context,
            produto_id,
        )
        return

    # =====================================================
    # CONFIRMAR COMPRA EM QUANTIDADE
    # =====================================================

    if acao.startswith("confirmar_compra_"):
        partes = acao.split("_")

        try:
            produto_id = int(partes[2])
            quantidade = int(partes[3])
        except (ValueError, IndexError):
            await query.answer(
                "❌ Compra inválida.",
                show_alert=True,
            )
            return

        await comprar_produto(
            query,
            context,
            produto_id,
            usuario_id,
            quantidade,
        )

        context.user_data["quantidade_produto"] = None
        return

    # =====================================================
    # COMPRAR
    # =====================================================

    if acao.startswith("comprar_"):
        try:
            produto_id = int(
                acao.split("_", 1)[1]
            )
        except (ValueError, IndexError):
            await query.answer(
                "❌ Produto inválido.",
                show_alert=True,
            )
            return

        await comprar_produto(
            query,
            context,
            produto_id,
            usuario_id,
            1,
        )
        return

    # =====================================================
    # SALDO
    # =====================================================

    if acao == "saldo":
        saldo = float(
            consultar_saldo(usuario_id) or 0
        )

        botoes_saldo = [
            [
                InlineKeyboardButton(
                    "💵 Adicionar saldo",
                    callback_data="adicionar_saldo",
                )
            ],
            [
                InlineKeyboardButton(
                    "⬅️ Voltar",
                    callback_data="voltar_menu",
                )
            ],
        ]

        await editar_ou_substituir(
            query,
            context,
            "💳 *MEU SALDO*\n\n"
            f"💰 Saldo atual: R$ {saldo:.2f}\n\n"
            "Escolha uma opção:",
            reply_markup=InlineKeyboardMarkup(
                botoes_saldo
            ),
            parse_mode="Markdown",
        )
        return

    # =====================================================
    # ADICIONAR SALDO
    # =====================================================

    if acao == "adicionar_saldo":
        await pedir_valor_saldo(
            query,
            context,
        )
        return

    # =====================================================
    # VOLTAR
    # =====================================================

    if acao == "voltar_menu":
        context.user_data.clear()

        try:
            await query.message.delete()
        except Exception:
            pass

        await enviar_menu_principal(
            query.message.chat_id,
            context,
            "🛒 *PLAYER STORE*\n\n"
            "Escolha uma opção abaixo:",
        )
        return

    # =====================================================
    # GRUPO
    # =====================================================

    if acao == "grupo":
        botoes_grupo = InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(
                        "👥 Entrar no grupo",
                        url=GRUPO_CLIENTES,
                    )
                ],
                [
                    InlineKeyboardButton(
                        "⬅️ Voltar",
                        callback_data="voltar_menu",
                    )
                ],
            ]
        )

        await editar_ou_substituir(
            query,
            context,
            "👥 *GRUPO DE CLIENTES*\n\n"
            "Entre no nosso grupo para acompanhar "
            "novidades e referências.",
            reply_markup=botoes_grupo,
            parse_mode="Markdown",
        )
        return

    # =====================================================
    # PERFIL
    # =====================================================

    if acao == "perfil":
        usuario = consultar_usuario(usuario_id)
        saldo = float(
            consultar_saldo(usuario_id) or 0
        )

        nome = (
            query.from_user.full_name
            or query.from_user.first_name
            or "Usuário"
        )

        username = query.from_user.username

        texto_username = (
            f"@{username}"
            if username
            else "Não informado"
        )

        await editar_ou_substituir(
            query,
            context,
            "👤 *MEU PERFIL*\n\n"
            f"🧑 Nome: {nome}\n"
            f"🔗 Username: {texto_username}\n"
            f"🆔 ID: `{usuario_id}`\n\n"
            f"💰 Saldo: R$ {saldo:.2f}",
            reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(
                            "⬅️ Voltar",
                            callback_data="voltar_menu",
                        )
                    ]
                ]
            ),
            parse_mode="Markdown",
        )
        return

    # =====================================================
    # TERMOS DE USO
    # =====================================================

    if acao == "termos":
        await editar_ou_substituir(
            query,
            context,
            "📜 *TERMOS DE USO*\n"
            "━━━━━━━━━━━━━━━━━━\n\n"
            "⚠️ Ao confirmar uma compra, você concorda "
            "com todas as regras abaixo.\n\n"
            "━━━━━━━━━━━━━━━━━━\n"
            "🕐 *HORÁRIO DE ATENDIMENTO*\n"
            "━━━━━━━━━━━━━━━━━━\n\n"
            "Nosso suporte funciona, em geral, das "
            "11h às 21h.\n"
            "Aos finais de semana e feriados o "
            "atendimento pode estar indisponível.\n\n"
            "━━━━━━━━━━━━━━━━━━\n"
            "🆘 *COMO SOLICITAR SUPORTE*\n"
            "━━━━━━━━━━━━━━━━━━\n\n"
            "1️⃣ Clique em SUPORTE no menu do bot\n"
            "2️⃣ Descreva o seu problema com clareza\n"
            "3️⃣ Aguarde um administrador responder\n\n"
            "📌 É obrigatório enviar:\n"
            "• 📸 Print do erro\n"
            "• 🔑 Login exatamente como recebido\n"
            "• 📅 Data da compra\n\n"
            "Sem esses dados não é possível dar "
            "suporte.\n\n"
            "━━━━━━━━━━━━━━━━━━\n"
            "❗ *REGRAS IMPORTANTES*\n"
            "━━━━━━━━━━━━━━━━━━\n\n"
            "• ❌ Não altere o e-mail das contas — "
            "perde o suporte\n"
            "• 💰 Reembolso só em saldo do bot, "
            "nunca em Pix\n"
            "• 🤝 Respeito é essencial — ofensas "
            "levam a banimento e perda do saldo\n\n"
            "━━━━━━━━━━━━━━━━━━\n"
            "⏳ *PRAZOS*\n"
            "━━━━━━━━━━━━━━━━━━\n\n"
            "• Retorno em até 24 a 48 horas\n"
            "• Se passar disso, você recebe em "
            "saldo o valor proporcional aos dias "
            "pendentes\n"
            "• Problemas com login online: "
            "resolvidos na hora\n\n"
            "━━━━━━━━━━━━━━━━━━\n\n"
            "✅ Ao prosseguir, você confirma que "
            "leu e aceita.",
            reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(
                            "↩️ Voltar ao menu",
                            callback_data="voltar_menu",
                        )
                    ]
                ]
            ),
            parse_mode="Markdown",
        )
        return

    # =====================================================
    # AJUDA
    # =====================================================

    if acao == "ajuda":
        await editar_ou_substituir(
            query,
            context,
            "❓ *AJUDA*\n\n"
            "🛒 *Comprar produto*\n"
            "Escolha um produto no catálogo e clique em Comprar.\n\n"
            "🛍️ *Comprar em quantidade*\n"
            "Escolha a quantidade desejada e confirme a compra.\n\n"
            "💳 *Adicionar saldo*\n"
            "Escolha o valor e o bot irá gerar um PIX automaticamente.\n\n"
            "💰 *Saldo*\n"
            "Veja seu saldo disponível.\n\n"
            "⚡ *Pagamento automático*\n"
            "Depois de pagar o PIX, não é necessário enviar comprovante "
            "nem ficar consultando manualmente.\n\n"
            "🤖 O sistema verifica automaticamente a confirmação.",
            reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(
                            "⬅️ Voltar",
                            callback_data="voltar_menu",
                        )
                    ]
                ]
            ),
            parse_mode="Markdown",
        )
        return

    # =====================================================
    # SUPORTE
    # =====================================================

    if acao == "suporte":
        await pedir_suporte(
            query,
            context,
        )
        return

    # =====================================================
    # RENOVAR CONTA
    # =====================================================

    if acao == "renovar_conta":
        await mostrar_historico_renovacao(
            query,
            context,
            usuario_id,
        )
        return

    if acao.startswith("renovar_login_"):

        try:
            login_id = int(
                acao.replace(
                    "renovar_login_",
                    "",
                    1,
                )
            )
        except ValueError:
            await query.answer(
                "❌ Conta inválida.",
                show_alert=True,
            )
            return

        await renovar_conta(
            query,
            context,
            usuario_id,
            login_id,
        )
        return

    # =====================================================
    # JOGOS NA TV
    # =====================================================

    if acao == "jogos_tv":
        await mostrar_jogos_tv(
            query,
            context,
        )
        return

    if acao.startswith("historico_compras_"):

        pagina_texto = acao.replace(
            "historico_compras_", ""
        )

        try:
            pagina = int(pagina_texto)
        except ValueError:
            pagina = 0

        await mostrar_historico_compras(
            query,
            context,
            pagina=pagina,
        )
        return

    if acao.startswith("ver_pedido_"):

        pedido_id_texto = acao.replace(
            "ver_pedido_", ""
        )

        try:
            pedido_id = int(pedido_id_texto)
        except ValueError:
            await query.answer(
                "❌ Pedido inválido.",
                show_alert=True,
            )
            return

        await mostrar_detalhes_pedido(
            query,
            context,
            pedido_id,
        )
        return

    # =====================================================
    # TERMOS DE USO (bloco duplicado removido)
    # =====================================================

    # =====================================================
    # ESTOQUE VAZIO
    # =====================================================

    if acao == "sem_estoque":
        await query.answer(
            "📦 No momento não há produtos disponíveis.",
            show_alert=True,
        )
        return

    # =====================================================
    # OUTROS BOTS
    # =====================================================

    if acao == "outros_bots":
        await editar_ou_substituir(
            query,
            context,
            "🤖 *OUTROS BOTS*\n\n"
            "Confira nossos outros bots:",
            reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(
                            "🔑 Bot de Códigos",
                            url=(
                                "https://t.me/"
                                "PlayerStoreCodigosBot"
                            ),
                        )
                    ],
                    [
                        InlineKeyboardButton(
                            "⬅️ Voltar",
                            callback_data="voltar_menu",
                        )
                    ],
                ]
            ),
            parse_mode="Markdown",
        )
        return

    # =====================================================
    # ALUGAR BOT
    # =====================================================

    if acao == "alugar_bot":
        await editar_ou_substituir(
            query,
            context,
            "📣 *ALUGAR ESTE BOT*\n\n"
            "Quer ter um bot igual a este pro seu "
            "negócio? Fale comigo diretamente.",
            reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(
                            "💬 Falar com o responsável",
                            url=(
                                "https://t.me/"
                                "PLAYERSTORE_OFICIAL"
                            ),
                        )
                    ],
                    [
                        InlineKeyboardButton(
                            "⬅️ Voltar",
                            callback_data="voltar_menu",
                        )
                    ],
                ]
            ),
            parse_mode="Markdown",
        )
        return

    # =====================================================
    # ENCOMENDA (PRÉ-VENDA)
    # =====================================================

    if acao == "fazer_encomenda":
        await iniciar_encomenda(
            query,
            context,
        )
        return

    if acao.startswith("encomenda_valor_"):

        if not eh_admin_principal(usuario_id):
            await query.answer(
                "❌ Acesso negado.",
                show_alert=True,
            )
            return

        encomenda_id = acao.replace(
            "encomenda_valor_",
            "",
            1,
        )

        context.user_data.clear()
        context.user_data[
            "admin_acao"
        ] = "definir_valor_encomenda"
        context.user_data[
            "encomenda_id"
        ] = encomenda_id

        await query.answer()

        await query.message.reply_text(
            "💰 Digite o valor a cobrar por essa "
            "encomenda (só o número).\n\n"
            "Exemplo:\n"
            "`25`\n"
            "`49,90`",
            parse_mode="Markdown",
        )
        return

    if acao.startswith("encomenda_recusar_"):

        if not eh_admin_principal(usuario_id):
            await query.answer(
                "❌ Acesso negado.",
                show_alert=True,
            )
            return

        encomenda_id = acao.replace(
            "encomenda_recusar_",
            "",
            1,
        )

        encomenda = obter_encomenda(encomenda_id)

        if not encomenda:
            await query.answer(
                "❌ Encomenda não encontrada.",
                show_alert=True,
            )
            return

        cancelar_encomenda(encomenda_id)

        cliente_id = encomenda[1]

        try:
            await context.bot.send_message(
                chat_id=cliente_id,
                text=(
                    "❌ *ENCOMENDA RECUSADA*\n\n"
                    "Infelizmente não conseguimos "
                    "atender esse pedido desta vez. "
                    "Fica à vontade pra tentar com "
                    "outro pedido!"
                ),
                parse_mode="Markdown",
            )
        except Exception as erro:
            log_erro(
                "ERRO AO AVISAR RECUSA:",
                repr(erro),
            )

        await query.answer(
            "✅ Encomenda recusada.",
        )

        try:
            await query.edit_message_reply_markup(
                reply_markup=None
            )
        except Exception:
            pass

        return

    if acao.startswith("encomenda_pagar_"):

        encomenda_id = acao.replace(
            "encomenda_pagar_",
            "",
            1,
        )

        encomenda = obter_encomenda(encomenda_id)

        if not encomenda:
            await query.answer(
                "❌ Encomenda não encontrada.",
                show_alert=True,
            )
            return

        (
            _id,
            cliente_id,
            descricao,
            valor,
            status,
            _criado_em,
        ) = encomenda

        if cliente_id != usuario_id:
            await query.answer(
                "❌ Essa encomenda não é sua.",
                show_alert=True,
            )
            return

        if status != "aguardando_pagamento":
            await query.answer(
                "❌ Essa encomenda já foi paga, "
                "recusada ou ainda não tem valor "
                "definido.",
                show_alert=True,
            )
            return

        saldo = float(
            consultar_saldo(usuario_id) or 0
        )

        if saldo < float(valor):
            faltando = float(valor) - saldo
            await query.answer()
            await query.message.reply_text(
                "❌ *SALDO INSUFICIENTE*\n\n"
                f"💰 *Valor da encomenda:* "
                f"R$ {float(valor):.2f}\n"
                f"💵 *Seu saldo:* R$ {saldo:.2f}\n"
                f"➕ *Falta:* R$ {faltando:.2f}\n\n"
                "Adicione saldo e tente pagar de "
                "novo.",
                reply_markup=InlineKeyboardMarkup(
                    [
                        [
                            InlineKeyboardButton(
                                "💵 Adicionar Saldo",
                                callback_data=(
                                    "adicionar_saldo"
                                ),
                            )
                        ]
                    ]
                ),
                parse_mode="Markdown",
            )
            return

        sucesso = retirar_saldo(
            usuario_id,
            float(valor),
        )

        if not sucesso:
            await query.answer(
                "❌ Não foi possível debitar o "
                "saldo. Tente novamente.",
                show_alert=True,
            )
            return

        marcar_encomenda_paga(encomenda_id)

        await query.answer(
            "✅ Pagamento confirmado!",
        )

        try:
            await query.edit_message_text(
                "✅ *PAGAMENTO CONFIRMADO!*\n\n"
                f"📋 *Pedido:* {descricao}\n"
                f"💰 *Valor pago:* "
                f"R$ {float(valor):.2f}\n\n"
                "Aguarde, vamos entregar em breve.",
                parse_mode="Markdown",
            )
        except Exception:
            pass

        try:
            await context.bot.send_message(
                chat_id=ADMIN_ID,
                text=(
                    "💰 *ENCOMENDA PAGA!*\n\n"
                    "━━━━━━━━━━━━━━━━━━\n"
                    f"🆔 *Encomenda:* `#{encomenda_id}`\n"
                    f"🆔 *Cliente:* `{cliente_id}`\n"
                    f"💰 *Valor:* R$ {float(valor):.2f}\n"
                    "━━━━━━━━━━━━━━━━━━\n\n"
                    f"📋 *Pedido:*\n{descricao}\n\n"
                    "Hora de entregar!"
                ),
                reply_markup=InlineKeyboardMarkup(
                    [
                        [
                            InlineKeyboardButton(
                                "📦 Entregar agora",
                                callback_data=(
                                    "encomenda_entregar_"
                                    f"{encomenda_id}"
                                ),
                            )
                        ]
                    ]
                ),
                parse_mode="Markdown",
            )
        except Exception as erro:
            log_erro(
                "ERRO AO AVISAR PAGAMENTO "
                "(ENCOMENDA):",
                repr(erro),
            )

        return

    if acao.startswith("encomenda_entregar_"):

        if not eh_admin_principal(usuario_id):
            await query.answer(
                "❌ Acesso negado.",
                show_alert=True,
            )
            return

        encomenda_id = acao.replace(
            "encomenda_entregar_",
            "",
            1,
        )

        encomenda = obter_encomenda(encomenda_id)

        if not encomenda or encomenda[4] != "pago":
            await query.answer(
                "❌ Essa encomenda não está "
                "com pagamento confirmado.",
                show_alert=True,
            )
            return

        context.user_data.clear()
        context.user_data[
            "admin_acao"
        ] = "entregar_encomenda"
        context.user_data[
            "encomenda_id"
        ] = encomenda_id

        await query.answer()

        await query.message.reply_text(
            "✍️ Digite/cole agora o que vai ser "
            "enviado ao cliente (dados da conta, "
            "instruções, link etc). Tudo que você "
            "mandar será enviado direto pra ele."
        )
        return

    # =====================================================
    # DESCONHECIDO
    # =====================================================

    await query.answer(
        "❌ Opção não reconhecida.",
        show_alert=True,
    )


# =========================================================
# ERRO GLOBAL
# =========================================================

async def erro_global(
    update: object,
    context: ContextTypes.DEFAULT_TYPE,
):
    log_erro("❌ ERRO GLOBAL:")
    log_info(repr(context.error))


# =========================================================
# MAIN
# =========================================================

def main():
    verificar_configuracao()
    criar_tabelas()

    application = (
        Application.builder()
        .token(BOT_TOKEN)
        .concurrent_updates(True)
        .post_init(iniciar_verificador)
        .post_shutdown(parar_verificador)
        .build()
    )

    application.add_handler(
        CommandHandler(
            "start",
            start,
        )
    )

    application.add_handler(
        CommandHandler(
            "admin",
            comando_admin,
        )
    )

    application.add_handler(
        CommandHandler(
            "grupoid",
            comando_grupo_id,
        )
    )

    application.add_handler(
        CommandHandler(
            "cadastrarlote",
            comando_cadastrarlote,
        )
    )

    application.add_handler(
        CommandHandler(
            "backup",
            comando_backup,
        )
    )

    application.add_handler(
        CommandHandler(
            "restaurar",
            comando_restaurar,
        )
    )

    application.add_handler(
        CommandHandler(
            "cancelar",
            cancelar_restauracao,
        )
    )

    application.add_handler(
        MessageHandler(
            filters.ChatType.PRIVATE
            & filters.Document.ALL,
            receber_banco_restaurar,
        )
    )

    application.add_handler(
        CommandHandler(
            "pix",
            comando_pix,
        )
    )

    application.add_handler(
        CommandHandler(
            "id",
            comando_id,
        )
    )

    application.add_handler(
        InlineQueryHandler(
            pesquisa_inline
        )
    )

    application.add_handler(
        CallbackQueryHandler(
            botoes
        )
    )

    application.add_handler(
        MessageHandler(
            filters.StatusUpdate.NEW_CHAT_MEMBERS,
            boas_vindas_novo_membro,
        )
    )

    application.add_handler(
        MessageHandler(
            filters.StatusUpdate.LEFT_CHAT_MEMBER,
            despedida_membro,
        )
    )

    application.add_handler(
        MessageHandler(
            filters.ChatType.GROUPS
            & (filters.TEXT | filters.PHOTO),
            responder_suporte_topico,
        )
    )

    application.add_handler(
        MessageHandler(
            filters.ChatType.PRIVATE
            & filters.REPLY
            & (filters.TEXT | filters.PHOTO),
            responder_suporte_admin,
        )
    )

    application.add_handler(
        MessageHandler(
            filters.PHOTO | filters.ANIMATION,
            processar_midia_generico,
        )
    )

    application.add_handler(
        MessageHandler(
            filters.TEXT & ~filters.COMMAND,
            processar_mensagem_texto,
        )
    )

    application.add_error_handler(
        erro_global
    )

    log_info("🤖 PLAYER STORE iniciado!")
    log_info("👑 Painel ADM: /admin")
    log_info(
        "💳 Verificador PIX: asyncio "
        f"(intervalo de {INTERVALO_VERIFICACAO}s)"
    )

    application.run_polling(
        drop_pending_updates=True
    )


# =========================================================
# EXECUTAR
# =========================================================

if __name__ == "__main__":
    main()
